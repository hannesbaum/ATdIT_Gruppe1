package com.example.d070700.demoapp;

class Person {
    String name;
    String age;
    String photoId;

    Person(String name, String age, String photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}