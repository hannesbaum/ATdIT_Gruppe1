package com.example.d070700.demoapp;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CustomerAppoint implements SqlQueryObject {

    private String name, address, addition, zip, city, phone, notes, email, mobile, phoneBusi, emailBusi, time, duration, id;
    private LocalTime lt;

    @RequiresApi(api = Build.VERSION_CODES.O)
    CustomerAppoint(String name, String address, String addition, String zip, String city, String phone,
                    String notes, String email, String mobile, String phoneBusi, String emailBusi, String time, String duration, String id) {
        this.name = usefulString(name);
        this.addition = usefulString(addition);
        this.address = usefulString(address);
        this.zip = usefulString(zip);
        this.phone = usefulString(phone);
        this.city = usefulString(city);
        this.notes = usefulString(notes);
        if (time == "''")
            this.time = "No time";
        else {
            this.time = usefulString(time);
            System.out.println("TIME : " + time);
            if (time.length() == 7)
                lt = LocalTime.parse(usefulString(time), DateTimeFormatter.ofPattern("HH:mm"));
        }
        this.mobile = usefulString(mobile);
        this.email = usefulString(email);
        this.emailBusi = usefulString(emailBusi);
        this.phoneBusi = usefulString(phoneBusi);
        this.duration = usefulString(duration);
        this.id = id;

    }

    public String getId(){
        return this.id;
    }

    public String getDuration(){
        return this.duration;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddition(String addition) {
        this.addition = addition;
    }

    public String getAddition() {
        return this.addition;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getZip() {
        return zip;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return this.city;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getNotes() {
        return this.notes;
    }

    public String getMobile() {
        return this.mobile;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPhoneBusi() {
        return this.phoneBusi;
    }

    public String getEmailBusi() {
        return this.emailBusi;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getTime() {
        if (lt != null) {
            String getMin = "0";
            String getHo = "0";
            if (lt.getHour() < 10)
                getHo += lt.getHour();
            else
                getHo = "" + lt.getHour();
            if (lt.getMinute() < 10)
                getMin += lt.getMinute();
            else
                getMin = "" + lt.getHour();
            return getHo + ":" + getMin;
        } else
            return null;
    }

    @Override
    public String usefulString(String str) {
        String local = "";
        StringBuilder builder = new StringBuilder(str);
        if (builder.charAt(0) == '\"')
            builder.deleteCharAt(0);
        if (builder.charAt(builder.length() - 1) == '\"')
            builder.deleteCharAt(builder.length() - 1);
        local = builder.toString();
        return local;
    }
}
