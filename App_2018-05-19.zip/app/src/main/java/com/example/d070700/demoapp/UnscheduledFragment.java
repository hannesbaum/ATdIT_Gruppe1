package com.example.d070700.demoapp;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UnscheduledFragment extends Fragment {

    protected RecyclerView mRecyclerView;
    protected UnscheduledAdapter mAdapter;
    protected RecyclerView.LayoutManager mLayoutManager;
    private List<CustomerAppoint> customers;
    private JsonArray query = new JsonArray();
    private String scheduleSuccess = "";
    private CustomerAppoint customerAppoint;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // DB connection to fetch data
        try {
            new ConnectDBTask().execute().get();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recycler_view_fragment, container, false);
        rootView.setTag("UnscheduledFragment");

        mRecyclerView = rootView.findViewById(R.id.recyclerView);

        mLayoutManager = new LinearLayoutManager((getActivity()));

        //create adapter for data
        ArrayList<JsonObject> list = new ArrayList<>();
        for (JsonElement obj : query) {
            list.add((JsonObject) obj);
        }
        System.out.println("CREATE unscheduled ADAPTER: " + list.get(0));
        createDataset(list);
        mAdapter = new UnscheduledAdapter(customers, this);

        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.setLayoutManager(mLayoutManager);


        return rootView;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createDataset(ArrayList<JsonObject> list) {
        customers = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            JsonObject local = list.get(i);
            customers.add(new CustomerAppoint(
                    local.get("lastName").toString(),
                    local.get("address").toString(),
                    local.get("addition").toString(),
                    local.get("zip").toString(),
                    local.get("city").toString(),
                    local.get("phone").toString(),
                    local.get("notes").toString(),
                    local.get("email").toString(),
                    local.get("mobile").toString(),
                    local.get("phoneBusi").toString(),
                    local.get("emailBusi").toString(),
                    local.get("start").toString(),
                    local.get("duration").toString(),
                    local.get("id").toString()));
        }
    }

    public void change(CustomerAppoint customer) {
        System.out.println("Chance occured");
        //popup window button "schedule
        customerAppoint = customer;
        AlertDialog.Builder builder;
        // version check
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(getActivity(), android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(getActivity());
        }
        builder.setTitle("Schedule Appointment")
                .setMessage("Do you want to schedule this appointment automatically?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                    try {
                        dialog.dismiss();
                        new ScheduleApt().execute().get();
                        System.out.println("Result: " + scheduleSuccess);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                })
                .setNegativeButton(android.R.string.no, (dialog, which) -> {
                    // do nothing
                })
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }


    private class ScheduleApt extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... appoint) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                PrintWriter toServer = new PrintWriter(socketToServer.getOutputStream(), true);
                String id = customerAppoint.getId();
                System.out.println("APPOINTMENT ID: " + id);
                toServer.println("schedule");
                String dummy = (String) fromServer.readObject();
                toServer.println(id);
                try {
                    String transfer = (String) fromServer.readObject();
                    if (transfer == "success") {
                        scheduleSuccess = "Appointment scheduled!";
                    } else if (transfer == "failedSQL") {
                        scheduleSuccess = "SQL Error!";
                    } else if (transfer == "failedApt") {
                        scheduleSuccess = "Error!";
                    }
                    Snackbar snackbar = Snackbar.make(getView(), transfer, Snackbar.LENGTH_SHORT);
                    snackbar.show();

                } catch (Exception e) {

                }
                socketToServer.close();
            } catch (Exception e) {

            }
            return null;
        }
    }

    private class ConnectDBTask extends AsyncTask<Void, Integer, Void> {

        JsonArray local = new JsonArray();

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                //BufferedReader query = new BufferedReader(new InputStreamReader(System.in));
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                PrintWriter toServer = new PrintWriter(socketToServer.getOutputStream(), true);

                System.out.println((String) fromServer.readObject());
                //String input = query.readLine();
                String input = "undated";
                toServer.println(input);
                try {
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    local = gson.fromJson(transfer, JsonArray.class);
                    System.out.println(local);
                    JsonObject obj = (JsonObject) local.get(0);
                    System.out.println("name: " + obj.get("name"));
                    query = local;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //System.out.println(fromServer.readLine());
                //toServer.println(query.readLine());
                //System.out.println(fromServer.readLine());
                socketToServer.close();
                //query.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}