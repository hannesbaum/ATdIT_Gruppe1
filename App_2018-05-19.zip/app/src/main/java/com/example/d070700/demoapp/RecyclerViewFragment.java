package com.example.d070700.demoapp;

import android.app.Activity;
import android.content.ClipData;

import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.*;

import org.json.*;

public class RecyclerViewFragment extends Fragment {

    protected RecyclerView mRecyclerView;
    protected CustomAdapter mAdapter;
    protected RecyclerView.LayoutManager mLayoutManager;
    private List<CustomerAppoint> customers;
    private JsonArray query = new JsonArray();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //createDataset();
        try {
            new ConnectDBTask().execute().get();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recycler_view_fragment, container, false);
        rootView.setTag("RecyclerViewFragment1");

        mRecyclerView = rootView.findViewById(R.id.recyclerView);

        mLayoutManager = new LinearLayoutManager((getActivity()));

        ArrayList<JsonObject> list = new ArrayList<>();
        for (JsonElement obj : query) {
            list.add((JsonObject) obj);
        }
        //System.out.println("CREATE ADAPTER: " + list.get(0));
        createDataset(list);
        mAdapter = new CustomAdapter(customers, this);

        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.setLayoutManager(mLayoutManager);

        return rootView;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createDataset(ArrayList<JsonObject> list) {

        customers = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            JsonObject local = list.get(i);
            customers.add(new CustomerAppoint(
                    local.get("lastName").toString(),
                    local.get("address").toString(),
                    local.get("addition").toString(),
                    local.get("zip").toString(),
                    local.get("city").toString(),
                    local.get("phone").toString(),
                    local.get("notes").toString(),
                    local.get("email").toString(),
                    local.get("mobile").toString(),
                    local.get("phoneBusi").toString(),
                    local.get("emailBusi").toString(),
                    local.get("start").toString(),
                    local.get("duration").toString(),
                    local.get("id").toString()));
        }
    }

    public void change(CustomerAppoint customer) {
        System.out.println("Chance occured");
        ((MainActivity) getActivity()).transferButtons("detail", customer);
    }


    private class ConnectDBTask extends AsyncTask<Void, Integer, Void> {

        JsonArray local = new JsonArray();

        @Override
        protected Void doInBackground(Void... var) {
            try {
                //BufferedReader query = new BufferedReader(new InputStreamReader(System.in));
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                PrintWriter toServer = new PrintWriter(socketToServer.getOutputStream(), true);

                System.out.println((String) fromServer.readObject());
                //String input = query.readLine();
                String input = "query";
                toServer.println(input);
                try {
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    local = gson.fromJson(transfer, JsonArray.class);
                    System.out.println(local);
                    JsonObject obj = (JsonObject) local.get(0);
                    System.out.println("name: " + obj.get("name"));
                    query = local;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //System.out.println(fromServer.readLine());
                //toServer.println(query.readLine());
                //System.out.println(fromServer.readLine());
                socketToServer.close();
                //query.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }


/*        @Override
        protected void onPostExecute(Void var) {
            query = local;
            System.out.println("ON_POST: FINISH");
*//*            notifyDataSetChanged();
            source.mAdapter.notifyDataSetChanged();*//*
            super.onPostExecute(var);
        }*/
    }


}

