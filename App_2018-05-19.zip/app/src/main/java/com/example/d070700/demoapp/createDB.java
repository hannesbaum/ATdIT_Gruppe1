package com.example.d070700.demoapp;

import android.database.sqlite.SQLiteDatabase;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author sqlitetutorial.net
 */
public class createDB {

    /**
     * Connect to a sample database
     *
     * @param fileName the database file name
     */
    public static void createNewDatabase(String fileName) {

        String url = "C:/Users/D070700/Desktop/" + fileName;

        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase("LocalDB", null);

        db.execSQL("CREATE TABLE IF NOT EXISTS " + "person" + " (Field1 VARCHAR, Field2 INT(3));");

        System.out.println("db created");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        createNewDatabase("test.db");
    }
}
