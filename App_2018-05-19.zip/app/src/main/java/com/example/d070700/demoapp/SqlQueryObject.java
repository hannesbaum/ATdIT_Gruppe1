package com.example.d070700.demoapp;

public interface SqlQueryObject {

    String usefulString(String string);
}
