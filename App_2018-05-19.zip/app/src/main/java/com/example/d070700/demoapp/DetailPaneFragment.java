package com.example.d070700.demoapp;

import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class DetailPaneFragment extends Fragment {

    CustomerAppoint customer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getActivity().getIntent();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.detail_pane2, container, false);
        rootView.setTag("RecyclerViewFragment1");
        TextView address = rootView.findViewById(R.id.AdressText),
                addition = rootView.findViewById(R.id.AdressAdditionText),
                zip = rootView.findViewById(R.id.ZipText),
                city = rootView.findViewById(R.id.CityText),
                phone = rootView.findViewById(R.id.PhoneText),
                notes = rootView.findViewById(R.id.NotesText);

        if (customer != null) {
            address.setText(customer.getAddress());
            addition.setText(customer.getAddition());
            zip.setText(customer.getZip());
            city.setText(customer.getCity());
            phone.setText(customer.getPhone());
            notes.setText(customer.getNotes());
        }


        final Button contact = rootView.findViewById(R.id.ContactButton);
        contact.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (customer != null)
                    ((MainActivity)getActivity()).transferButtons("contact", customer);
                    System.out.println("Contact the world " + customer.getName());
            }
        });


        final Button setData = rootView.findViewById(R.id.SetValuesButton);
        setData.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(customer != null){
                    //((MainActivity)getActivity()).onClickSetData(customer);
                    ((MainActivity)getActivity()).transferButtons("setData", customer);
                    System.out.println("value setting");
                }
            }
        });

        final Button editData = rootView.findViewById(R.id.EditValuesButton);
        editData.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(customer != null){
                    System.out.println("EDITTT");
                }
            }
        });

        return rootView;
    }

    public void setCustomer(CustomerAppoint customer) {
        this.customer = customer;
    }
}
