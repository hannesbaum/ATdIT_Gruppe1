package com.example.d070700.demoapp;

import android.database.sqlite.SQLiteDatabase;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

class AuskunftServer {

    public static void main(String[] args) throws ClassNotFoundException {
        try {
            ServerSocket server = new ServerSocket(200);
            System.out.println("Server gestartet");
            while (true) {
                Socket s = server.accept();
                new AuskunftProtocol(s).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (RuntimeException e) { // catches Security and IAE Exceptions
            e.printStackTrace();
        }
    }
}

class AuskunftProtocol extends Thread {
    Socket s;
    BufferedReader fromClient;
    ObjectOutputStream toClient;
    int nr = 0;
    static int anzahl = 0;
    HashMap<String, String> numbers = new HashMap<>();
    private ResultSet resultSet;

    public AuskunftProtocol(Socket s) throws ClassNotFoundException {
        try {
            this.s = s;
            nr = ++anzahl;
            fromClient = new BufferedReader(new InputStreamReader(s.getInputStream()));
            toClient = new ObjectOutputStream(s.getOutputStream());
           // database();
        } catch (IOException e) {
            System.out.println("Error bei Client " + nr);
            e.printStackTrace();
        }
        fillMap();
    }

    public void run() {
        System.out.println("Protokoll für Client " + nr + " gestartet");
        try {
            while (true) {
                toClient.writeObject("Geben Sie ABFRAGE oder QUIT ein");
                String input = fromClient.readLine();
                if (input == null || input.equalsIgnoreCase("quit")) {
                    break;
                }
                if (input.equalsIgnoreCase("abfrage")) {
                    if (resultSet != null) {
                        ArrayList<Customer> list = new ArrayList<>();
                        Customer local;
                        while (resultSet.next()) {
                            System.out.println(resultSet.getString("name"));
                            local = new Customer(resultSet.getString("name"), resultSet.getString("address"),
                                    resultSet.getString("addition"), resultSet.getString("zip"),
                                    resultSet.getString("city"), resultSet.getString("phone"),
                                    resultSet.getString("notes"), resultSet.getString("email"),
                                    resultSet.getString("mobile"), resultSet.getString("phoneBusi"),
                                    resultSet.getString("emailBusi"), resultSet.getString("time"));
                            list.add(local);
                        }
                        toClient.writeObject(list);
                        //toClient.writeObject("Hello World");
                        // toClient.close();
                    }
                    //
                    // toClient.println("Zu welchem Namen soll die Nummer gesucht werden?");
                    // String name = fromClient.readLine();
                    // if (numbers.containsKey(name.toLowerCase())) {
                    // toClient.println(name + " hat die Nummer " + numbers.get(name));
                    // } else {
                    // toClient.println("Fï¿½r " + name + " konnte keine Nummer gefunden werden!");
                    // }
                } else {
                    // catch wrong input
                }
            }
            // System.out.println(nr);
            s.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Protokoll für Client " + nr + " beendet");
    }

    private void fillMap() {
        numbers.put("fischer", "1324567");
        numbers.put("meier", "225577");
        numbers.put("müller", "958771");
        numbers.put("schmidt", "330912");
    }

/*    public void database() throws ClassNotFoundException {
        // load the sqlite-JDBC driver using the current class loader
       // Class.forName("org.sqlite.JDBC");

        Connection connection = null;
        try {
            SQLiteDatabase db = SQLiteDatabase.openDatabase("C:\\Users\\D070700\\Documents\\HS_App\\app\\src\\main\\java\\com\\example\\d070700\\demoapp\\test.db", null, SQLiteDatabase.CREATE_IF_NECESSARY);

            db.execSQL("CREATE TABLE IF NOT EXISTS " + "person" + " (Field1 VARCHAR, Field2 INT(3));");

            System.out.println("db created");
        }

        catch (Exception e) {
            e.printStackTrace();
        }
    }*/
}
