package com.example.d070700.demoapp;


import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {


    public static class ViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        TextView personName;
        TextView personAddress;
        TextView personTime;
        CustomerAppoint currentItem;
        View view;

        ViewHolder(View itemView) {
            super(itemView);
            view = itemView;
            cv = (CardView) itemView.findViewById(R.id.cv);
            personName = (TextView) itemView.findViewById(R.id.customer_name);
            personAddress = (TextView) itemView.findViewById(R.id.customer_address);
            personTime = (TextView) itemView.findViewById(R.id.customer_time);
        }
    }

    List<CustomerAppoint> customers;
    RecyclerViewFragment source;

    public CustomAdapter(List<CustomerAppoint> customers, RecyclerViewFragment source) {
        this.customers = customers;
        this.source = source;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item, viewGroup, false);
        return new ViewHolder(v);
    }

    /**
     * Displays the individual customer data and sets onClickListener
     * @param holder - ViewHolder
     * @param i - i in List<Customer></Customer>
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int i) {
        holder.personName.setText(customers.get(i).getName());
        holder.personAddress.setText(customers.get(i).getAddress());
        holder.personTime.setText(customers.get(i).getTime());
        holder.currentItem = customers.get(i);
        holder.view.setOnClickListener(v -> source.change(holder.currentItem));
    }

    /**
     * @return - returns the size of the list with customers
     */
    @Override
    public int getItemCount() {
        return customers.size();
    }
}
