package com.example.d070700.demoapp;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentTransaction;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.example.d070700.demoapp.R.*;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    // API requirement because LocalDateTime is only available since Java 8
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // default implementation; savedInstanceState deals with active activities and how they are handled
        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            RecyclerViewFragment fragment = new RecyclerViewFragment();
            transaction.replace(id.sample_content_fragment, fragment, "recyclerView");
            transaction.commit();
        }

        // local method to set the current date
        refreshBasicInfos();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // drawer layout is refering to the left side layout
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // dummy call for backstack tracking
        //System.out.println("BackStackCount: " + getSupportFragmentManager().getBackStackEntryCount());
    }

    /**
     * This method constructs the next fragment based on the button pressed
     *
     * @param transfer - String which should identify the pressed button
     * @param customer - forward the customer, from which the Action originated to display customized data
     */
    protected void transferButtons(String transfer, SqlQueryObject customer) {
        TextView localTextView;
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        switch (transfer) {
            case "setData":
                DataInputFragment inputFragment = new DataInputFragment();
                transaction.replace(id.sample_content_fragment, inputFragment, transfer);
                break;
            case "contact":
                if (customer instanceof CustomerAppoint) {
                    CustomerAppoint local = (CustomerAppoint) customer;
                    ContactFragment contactFragment = new ContactFragment();
                    contactFragment.setCustomer(local);
                    transaction.replace(id.sample_content_fragment, contactFragment, transfer);
                }
                break;
            case "detail":
                if (customer instanceof CustomerAppoint) {
                    CustomerAppoint local = (CustomerAppoint) customer;
                    localTextView = findViewById(R.id.textView2);
                    localTextView.setText(local.getName());
                    DetailPaneFragment detailFragment = new DetailPaneFragment();
                    detailFragment.setCustomer(local);
                    transaction.replace(id.sample_content_fragment, detailFragment, transfer);
                }
                break;
            case "continueSetData":
                System.out.println("continueSetData Button pressed!");
                break;
            case "editData":
                System.out.println("editData Button pressed!");
                break;
        }
        // system procedures to follow the "standard fragment changing" operations
        transaction.addToBackStack(transfer);
        transaction.commit();
    }

    /**
     * Overwritten method which will check if the main activity header has to be changed; super() will be called
     * Requires API because of LocalDateTime is only available since Java 8
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBackPressed() {
        //close an open drawer menu if back is pressed
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
            android.support.v4.app.Fragment frag = getSupportFragmentManager().findFragmentByTag("detail");
            if (frag == null)
                refreshBasicInfos();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // start fragment
            goHome(item);
        } else if (id == R.id.nav_calendar) {
            goCalendar(item);
        } else if (id == R.id.nav_settings) {
            // settings fragment
            goSettings();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);        // closes drawer if new item has been selected
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void refreshBasicInfos() {
        TextView date = findViewById(R.id.textView2);       // "headline" textview which is part of the main activity
        LocalDateTime local = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd.MM.");  // date format: Weekday, Day, Month
        date.setText(local.format(formatter));
    }

    /**
     * Resetting the shown fragment back to the main fragment if the menu-item "Home" is pressed
     * Requires API because LocalDateTime is only available since Java 8
     *
     * @param item - will pass on the pressed item
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void goHome(MenuItem item) {
        // the whole backstack is deleted, as soon as you go home; pressing back will close the app
        for (int i = getSupportFragmentManager().getBackStackEntryCount(); i > 0; i--) {
            getSupportFragmentManager().popBackStack();
        }
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        RecyclerViewFragment recyclerView = new RecyclerViewFragment();
        transaction.replace(id.sample_content_fragment, recyclerView, "recyclerView");
        transaction.addToBackStack("recyclerView");
        transaction.commit();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        refreshBasicInfos();
        System.out.println(getSupportFragmentManager().getBackStackEntryCount());
    }

    /**
     * Setting the visible fragment to the calendar fragment
     *
     * @param item - the clicked menu item
     */
    private void goCalendar(MenuItem item) {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        for (int i = getSupportFragmentManager().getBackStackEntryCount(); i > 0; i--) {
            getSupportFragmentManager().popBackStack();
        }
        TextView localTextView = findViewById(R.id.textView2);
        localTextView.setText("Termine verwalten");     //headline is changed
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        UnscheduledFragment calendar = new UnscheduledFragment();
        transaction.replace(id.sample_content_fragment, calendar, "calendar");
        transaction.addToBackStack("calendar");
        transaction.commit();
    }

    /**
     * Changes the visible fragment to the settings fragment
     */
    private void goSettings() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        TextView localTextView = findViewById(R.id.textView2);
        localTextView.setText("Einstellungen");
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        SettingsFragment calendar = new SettingsFragment();
        transaction.replace(id.sample_content_fragment, calendar, "settings");
        transaction.addToBackStack("settings");
        transaction.commit();
    }
}