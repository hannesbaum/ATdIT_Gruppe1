package com.example.d070700.demoapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

public class DetailPaneActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_pane2);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();



        //Fill detail content
        TextView name = findViewById(R.id.personName),
                address = findViewById(R.id.AdressText),
                addition = findViewById(R.id.AdressAdditionText),
                zip = findViewById(R.id.ZipText),
                city = findViewById(R.id.CityText),
                phone = findViewById(R.id.PhoneText),
                notes = findViewById(R.id.NotesText);

        Bundle extras = intent.getExtras();
        //textView.setText(message);
        name.setText(extras.getString("name"));
        address.setText(extras.getString("address"));
        addition.setText(extras.getString("addition"));
        zip.setText(extras.getString("zip"));
        city.setText(extras.getString("city"));
        phone.setText(extras.getString("phone"));
        notes.setText(extras.getString("notes"));
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.nav_calendar) {

        } else if (id == R.id.nav_settings) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
