package com.example.d070700.demoapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.d070700.demoapp.Customer;
import com.example.d070700.demoapp.R;

public class ContactFragment extends Fragment {

    private final String cancel = "", delay = "", move = "";

    CustomerAppoint customer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.contact, container, false);
        rootView.setTag("RecyclerViewFragment1");

        TextView phone = rootView.findViewById(R.id.phoneDisplay),
                phoneMobile = rootView.findViewById(R.id.phoneDisplay2),
                phoneBusi = rootView.findViewById(R.id.phoneDisplayBusi),
                email = rootView.findViewById(R.id.emailDisplay),
                emailBusi = rootView.findViewById(R.id.emailDisplayBusi);

        if (customer != null) {
            phone.setText(customer.getPhone());
            phoneMobile.setText(customer.getMobile());
            phoneBusi.setText(customer.getPhoneBusi());
            email.setText(customer.getEmail());
            emailBusi.setText(customer.getEmailBusi());
        }

        phone.setOnClickListener((v) ->
                {
                    System.out.println("Call Customer");
                    String call = customer.getPhone();
//                    Intent intent = new Intent(Intent.ACTION_DIAL);
//                    intent.setData(Uri.parse(call));
//                    startActivity(intent);

                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + call));
                    startActivity(intent);
                }
        );

        phoneMobile.setOnClickListener((v) ->
            System.out.println("Call Customer Mobile")
        );

        phoneBusi.setOnClickListener((v) ->
            System.out.println("Call Customer Business")
        );


        final Button cancel = rootView.findViewById(R.id.cancelDate);
        cancel.setOnClickListener((v) ->
            System.out.println("Cancel pressed!")
        );

        final Button push = rootView.findViewById(R.id.pushDate);
        push.setOnClickListener((v) ->
            System.out.println("Push pressed!")
        );

        final Button later = rootView.findViewById(R.id.laterArrival);
        later.setOnClickListener((v) ->
            System.out.println("Later pressed!")
        );

        return rootView;
    }

    public void setCustomer(CustomerAppoint customer) {
        this.customer = customer;
    }
}