package com.example.d070700.demoapp;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

//import org.json.*;

class AuskunftClient {

    public static void main(String[] args) {
        try {
            BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in));
            Socket socketToServer = new Socket("localhost", 200);
            ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
            PrintWriter toServer = new PrintWriter(socketToServer.getOutputStream(), true);
            while (true) {
                System.out.println((String) fromServer.readObject());
                String input = fromUser.readLine();
                toServer.println(input);
                if (input.equalsIgnoreCase("quit")) {
                    break;
                }
                try {
                    //JsonArray array = new JsonArray();
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    JsonArray array = gson.fromJson(transfer, JsonArray.class);

                    //list = (ArrayList<Customer>) fromServer.readObject();
                    //Customer local = list.get(0);
                    //System.out.println(local.getName() + "; " + local.getAddress());
                    System.out.println(array);
                    JsonObject local = (JsonObject)array.get(0);
                    System.out.println(local.get("name"));
                    //System.out.println(array.get(0).);
                    //System.out.println((String)fromServer.readObject());
                } catch (Exception e) {
                    e.printStackTrace();
                    //System.err.println(e.getMessage());
                }
                System.out.println(fromServer.readLine());
                toServer.println(fromUser.readLine());
                System.out.println(fromServer.readLine());
            }
            socketToServer.close();
            fromUser.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (RuntimeException e) {        //catches Security and IAE exceptions
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

