package com.example.d070700.demoapp;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

public class Customer {

    private String name, address, addition, zip, city, phone, notes, email, mobile, phoneBusi, emailBusi;
    String time;

    Customer(String name) {
        this.name = name;
    }

    Customer(String name, String address, String addition, String zip, String city, String phone,
             String notes, String email, String mobile, String phoneBusi, String emailBusi, String time) {
        this.name = name;
        this.addition = addition;
        this.address = address;
        this.zip = zip;
        this.phone = phone;
        this.city = city;
        this.notes = notes;
        this.time = time;
        this.mobile = mobile;
        this.email = email;
        this.emailBusi = emailBusi;
        this.phoneBusi = phoneBusi;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddition(String addition) {
        this.addition = addition;
    }

    public String getAddition() {
        return this.addition;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getZip() {
        return zip;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return this.city;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getNotes() {
        return this.notes;
    }

    public String getMobile() {
        return this.mobile;
    }

    public String getEmail() {
        return this.email;
    }

    public String getPhoneBusi() {
        return this.phoneBusi;
    }

    public String getEmailBusi() {
        return this.emailBusi;
    }

/*    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getTime() {
        String output = "";
        if (time.getHour() < 10)
            output += "0" + time.getHour();
        else
            output += time.getHour();

        output += ":";
        if (time.getMinute() < 10)
            output += "0" + time.getMinute();
        else
            output += time.getMinute();

        return output;
    }*/
}