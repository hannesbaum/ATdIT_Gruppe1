package com.example.d070700.demoapp;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class DataInputFragment extends Fragment {
    Customer customer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.set_values, container, false);
        rootView.setTag("set_values_view");
        final Button cancelButton = rootView.findViewById(R.id.cancelButton);
        //if too many subfragments have been created, the useless fragements will be deleted from the backstack
        cancelButton.setOnClickListener(v -> {
            for( int i = ((MainActivity)getActivity()).getSupportFragmentManager().getBackStackEntryCount(); i > 3; i--){
                ((MainActivity)getActivity()).getSupportFragmentManager().popBackStack();
            }
            ((MainActivity) getActivity()).onBackPressed();
        });
        final Button continueButton = rootView.findViewById(R.id.continueButton);
        continueButton.setOnClickListener((v) -> {
                    //((MainActivity) getActivity()).transferButtons("continueSetData", customer);
                }
        );
        return rootView;
    }
}