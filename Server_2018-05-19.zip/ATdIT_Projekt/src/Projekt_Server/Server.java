package Projekt_Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.time.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

//import javax.json.*;
import com.google.gson.*;
import com.google.gson.GsonBuilder;

class Server {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			ServerSocket server = new ServerSocket(200);
			System.out.println("Server gestartet");
			while (true) {
				Socket s = server.accept();
				new AuskunftProtocol(s).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (RuntimeException e) { // catches Security and IAE Exceptions
			e.printStackTrace();
		}
	}
}

class AuskunftProtocol extends Thread {
	Socket s;
	BufferedReader fromClient;
	ObjectOutputStream toClient;
	int nr = 0;
	static int anzahl = 0;
	// HashMap<String, String> numbers = new HashMap<>();
	private ResultSet resultSet;

	public AuskunftProtocol(Socket s) throws ClassNotFoundException {
		try {
			this.s = s;
			nr = ++anzahl;
			fromClient = new BufferedReader(new InputStreamReader(s.getInputStream()));
			toClient = new ObjectOutputStream(s.getOutputStream());
		} catch (IOException e) {
			System.out.println("Error bei Client " + nr);
			e.printStackTrace();
		}
	}

	private String findDateTime(List<Appointment> aptList, Appointment tbd) {
		try {
			LocalDateTime now, possibleApt;
			Appointment addition, local; // tbd = appointment "to be dated", addition for adding
											// appointments to list, local for iterator
			// now = LocalDateTime.now();
			// LocalDate inTwoWeeks = now.toLocalDate().plusWeeks(2);
			LocalTime startWork = LocalTime.of(9, 0), endWork = LocalTime.of(16, 30);
			Iterator<Appointment> iterator = aptList.iterator();
			if (iterator.hasNext()) {
				while (iterator.hasNext()) {
					local = iterator.next();
					// if the list object's date is before the date tbd, skip until we are at the
					// same date

					// if tbd is before local (case: 2)
					// this means, that no appointment is on this certain day because:
					// case a: n apts have passed (tbd is after them) and the next is after tbd =
					// free date!
					// case b: the only date or all dates are after tbd = free date!
					if (tbd.getDate().isBefore(local.getDate())) {
						tbd.setStart(startWork);
					}

					// here we need to find a free timeslot on that exact day!!
					else if (local.getDate().equals(tbd.getDate())) {
						// if (local.getDate().getDayOfWeek() == DayOfWeek.SATURDAY
						// || local.getDate().getDayOfWeek() == DayOfWeek.SUNDAY) {
						// // case if local date is saturday or sunday -> apt is invalid!!!!!
						// }
						// tbd start is not allowed to be within another apt (between start and end of
						// another apt)

						// success case?!
						if (tbd.getEnd().plusMinutes(15).isBefore(local.getStart())) {
							// apt is valid!! --> leave it this way!
							// break from loop and return time to app and set it in database as valid date
							System.out.println("Appointment found");
							return "success";
						}

						// change from while to if?! --> check
						// implement equal cases
						if ((tbd.getStart().isAfter(local.getStart()) && tbd.getEnd().isBefore(local.getEnd()))
								|| tbd.getStart().equals(local.getStart()) || tbd.getEnd().equals(local.getEnd())
								|| (tbd.getStart().isBefore(local.getStart())
										&& tbd.getEnd().plusMinutes(15).isAfter(local.getStart()))
								|| (local.getStart().isBefore(tbd.getStart())
										&& local.getEnd().plusMinutes(15).isAfter(local.getStart()))) {
							// reset the start time to the end-time of the previous apt and check again
							tbd.setStart(local.getEnd().plusMinutes(15));

							// if you move into the endWork phase where the employee finishes working, skip
							// to the next day (not SAT/SUN) and reset time to 9am
							if (tbd.getStart().isAfter(endWork)) {
								if (tbd.getDate().getDayOfWeek() == DayOfWeek.FRIDAY) {
									tbd.setDate(tbd.getDate().plusDays(3));
								} else {
									tbd.setDate(tbd.getDate().plusDays(1));
								}
								tbd.setStart(startWork);
							}
						}
					}
				}
			} else {
				// list is empty, create standard apt
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "";
	}

	public void run() {
		Connection connection = null;
		Statement statement = null;
		JsonObject value = new JsonObject();
		JsonArray array = new JsonArray();
		String input = "", transfer = "";

		System.out.println("Protokoll f�r Client " + nr + " gestartet");
		try {
			while (true) {
				toClient.writeObject("Connection established");
				input = fromClient.readLine();
				try {
					// create a database connection
					// Syntax: "jdbc:sqlite:<<database_Name.db>>"
					connection = DriverManager.getConnection("jdbc:sqlite:first.db");
					statement = connection.createStatement();
				} catch (SQLException e) {
					System.err.println(e.getMessage());
				}
				if (input.equalsIgnoreCase("abfrage")) {
					Gson gson = new Gson();
					Class.forName("org.sqlite.JDBC");
					try {
						resultSet = statement.executeQuery("SELECT * from customer");
						System.out.println(resultSet);
						while (resultSet.next()) {
							value.addProperty("name", resultSet.getString("name"));
							value.addProperty("address", resultSet.getString("address"));
							value.addProperty("addition", resultSet.getString("addition"));
							value.addProperty("zip", resultSet.getString("zip"));
							value.addProperty("city", resultSet.getString("city"));
							value.addProperty("phone", resultSet.getString("phone"));
							value.addProperty("notes", resultSet.getString("notes"));
							value.addProperty("email", resultSet.getString("email"));
							value.addProperty("mobile", resultSet.getString("mobile"));
							value.addProperty("phoneBusi", resultSet.getString("phoneBusi"));
							value.addProperty("emailBusi", resultSet.getString("emailBusi"));
							value.addProperty("time", resultSet.getString("time"));
							value.addProperty("id", 0); // check this value !!!
							array.add(value);
							System.out.println("ResultSet value name: " + resultSet.getString("name"));
						}
						transfer = gson.toJson(array);
						System.out.println(transfer);
						toClient.writeObject(transfer);
					} catch (SQLException e) {
						System.err.println(e.getMessage());
					}
				} else if (input.equalsIgnoreCase("abrage")) {
					//
					// // String appointID = fromClient.readLine();
					//
					// // now as local system time; possibleApt as the possible time for an
					// appointment
					LocalDateTime now, possibleApt;
					Appointment tbd;// , addition, local; // tbd = appointment "to be dated", addition for adding
					// // appointments to list, local for iterator
					//
					// // SQL query
					// // resultSet = statement.executeQuery("Select * FROM Termin ... WHERE
					// appointID
					// // = " + appointID);
					//
					// // tbd = new Appointment(resultSet.getString("appointID"), null, null, null,
					// // resultSet.getString("taskID"),
					// // Integer.valueOf(resultSet.getString("taskTime")),
					// // resultSet.getString("status"), resultSet.getString("cycle"));
					//
					now = LocalDateTime.now();
					LocalDate inTwoWeeks = now.toLocalDate().plusWeeks(2);
					LocalTime startWork = LocalTime.of(9, 0); // , endWork = LocalTime.of(16, 30);

					tbd = new Appointment(null, null, null, null, null, 30, 0, 0);
					if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SATURDAY)
						inTwoWeeks = inTwoWeeks.plusDays(2);
					if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SUNDAY)
						inTwoWeeks = inTwoWeeks.plusDays(1);
					tbd.setDate(inTwoWeeks);
					tbd.setStart(startWork);

					List<Appointment> aptList = new ArrayList<>(); // store query results

					// to do: just active & in progress appointments !!! just from current and next
					// month !!! order by date
					// resultSet = statement.executeQuery(
					// "SELECT * FROM TERMIN INNER JOIN (SELECT ID, BezirkID FROM Wohnung INNER JOIN
					// Bezirk)");
					// while (resultSet.next()) {
					// addition = new Appointment(resultSet.getString("appointID"),
					// resultSet.getString("date"),
					// resultSet.getString("start"), resultSet.getString("end"),
					// resultSet.getString("taskID"),
					// Integer.valueOf(resultSet.getString("taskTime")),
					// Integer.valueOf(resultSet.getString("status")),
					// Integer.valueOf(resultSet.getString("cycle")));
					// aptList.add(addition);
					// }

					// ---------------------------------------
					// test data !!!
					Appointment one, two, three;
					one = new Appointment("1", "2018-06-04", "09:00", "09:30", null, 30, 2, 6);
					two = new Appointment("2", "2018-06-04", "10:00", "10:15", null, 15, 2, 6);
					three = new Appointment("3", "2018-06-04", "14:00", "14:30", null, 30, 2, 6);
					aptList.add(one);
					aptList.add(two);
					aptList.add(three);

					// -----------------------------------------

					String result = findDateTime(aptList, tbd);

					if (result == "success") {
						// set status to active
						String id = tbd.getAppointID();
						try {
							statement.executeUpdate("UPDATE Termin SET status = 2 WHERE id =" + id);
							toClient.writeObject("success");
						} catch (SQLException e) {
							toClient.writeObject("failedSQL");
							e.printStackTrace();
						}
					} else {
						toClient.writeObject("failedApt");
					}
				}
				// System.out.println(nr);
				s.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Protokoll f�r Client " + nr + " beendet");
	}

	private String fomatString(String str) {
		StringBuilder build = new StringBuilder(str);
		if (build.charAt(0) == '\"') {
			build.deleteCharAt(0);
		}
		if (build.charAt(build.length() - 1) == '\"') {
			build.deleteCharAt(build.length() - 1);
		}
		return build.toString();
	}
}
