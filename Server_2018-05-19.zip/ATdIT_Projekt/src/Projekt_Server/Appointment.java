package Projekt_Server;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class Appointment {

	private String appointID, taskID;
	int taskTime, status, cycle;
	private LocalDate date;
	private LocalTime start, end;

	/**
	 * Create an Appointment similar to the DB-object "Termin" to provide valid
	 * functionality of comparing dates and times
	 * 
	 * @param appointID
	 *            - String - unique identifier of an appointment
	 * @param date
	 *            - String - date of the appointment; format: "yyyy-mm-dd"
	 * @param start
	 *            - String - start time of the appointment; format: "hh:mm"
	 * @param end
	 *            - String -(optional) end time of the appointment; format: "hh:mm"
	 * @param taskID
	 *            - String - (optional) corresponding taskID of the appointment
	 * @param taskTime
	 *            - int - expected time to complete appointment; time in minutes
	 * @param status
	 *            - int - status of the appointment; valid are 0 = tbd; 2 = active;
	 *            3 = cpmpleted
	 * @param cycle
	 *            - int
	 * @throws IllegalArgumentException
	 */
	public Appointment(String appointID, String date, String start, String end, String taskID, int taskTime, int status,
			int cycle) throws IllegalArgumentException {

		if (appointID == null || appointID == "") {
			throw new IllegalArgumentException("appointID must be provided");
		}

		if (taskTime == 0) {
			throw new IllegalArgumentException("Task time cannot be 0");
		}

		// the date and start string are not allowed to be empty
		if (date == null || date == "" || start == null || start == "") {
			throw new IllegalArgumentException("Illegal Date/Time parameters");
		}

		// there are only three valid status codes:
		// 0 - to be dated; 2 - active; 3 - completed
		// code 1 was originally supposed to be "in progress for confirmation" but was
		// not implemented (yet)
		if (!(status == 0 || status == 2 || status == 3)) {
			throw new IllegalArgumentException("Illegal Status number");
		}

		// the date string has to be 10 characters long to be parsed into a LocalDate
		// object correctly
		if (date.length() != 10) {
			throw new IllegalArgumentException("Invalid length: date string");
		}

		// the starttime string has to be 6 characters long to be parsed correctly
		if (start.length() != 5) {
			throw new IllegalArgumentException("Invalid length: starttime string");
		}

		if (end != null && end != "") {
			if (end.length() == 5)
				this.end = LocalTime.parse(end, DateTimeFormatter.ofPattern("HH:mm"));
			else
				throw new IllegalArgumentException("Invalid length: endtime string");
		}

		this.date = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		this.start = LocalTime.parse(start, DateTimeFormatter.ofPattern("HH:mm"));
		this.appointID = appointID;
		this.taskID = taskID;
		this.taskTime = taskTime;
		this.status = status;
		this.cycle = cycle;
		// ------------------------ !!! ----------------------
		// is cycle neccessary???
		// a valid apt must have starttime (not null!!!)
	}

	public String getAppointID() {
		return this.appointID;
	}

	public String getTaskID() {
		return this.taskID;
	}

	public int getTaskTime() {
		return this.taskTime;
	}

	public int getStatus() {
		return this.status;
	}

	public int getCycle() {
		return this.cycle;
	}

	public LocalDate getDate() {
		return this.date;
	}

	public LocalTime getStart() {
		return this.start;
	}

	public LocalTime getEnd() {
		return this.end;
	}

	public void setDate(LocalDate date) throws NullPointerException {
		if (date != null)
			this.date = date;
		else
			throw new NullPointerException("No LocalDate Object provided");
	}

	public void setStart(LocalTime start) throws NullPointerException {
		if (start != null) {
			this.start = start;
			this.end = start.plusMinutes(taskTime);
		} else {
			throw new NullPointerException("No LocalTime Object provided");
		}
	}
}
