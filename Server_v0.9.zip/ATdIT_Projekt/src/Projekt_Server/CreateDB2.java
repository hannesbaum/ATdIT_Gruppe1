package Projekt_Server;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class CreateDB2 {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			Class.forName("org.sqlite.JDBC");

			Connection connection = DriverManager.getConnection("jdbc:sqlite:second.db");

			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30); // set timeout to 30 sec.

			// propmanagement = Property management/ Hausverwaltung
			statement.executeUpdate("DROP TABLE IF EXISTS propManagement");
			statement.executeUpdate("CREATE TABLE propManagement (manageId TEXT PRIMARY KEY, email TEXT,"
					+ " phone TEXT, contactPerson TEXT, charges TEXT, companyName TEXT)");
			
			//Apartment
			statement.executeUpdate("DROP TABLE IF EXISTS apartment");
			statement.executeUpdate("CREATE TABLE apartment (apartmentId TEXT PRIMARY KEY, address TEXT NOT NULL, addition TEXT NOT NULL,"
					+ "zip INTEGER NOT NULL, city TEXT NOT NULL, counterNr INTEGER NOT NULL, "
					+ "manageId TEXT REFERENCES propManagement(manageId), customerId TEXT REFERENCES customer(customerId))");

			//Mieter
			statement.executeUpdate("DROP TABLE IF EXISTS customer");
			statement.executeUpdate(
					"CREATE TABLE customer (customerId TEXT PRIMARY KEY, firstName TEXT NOT NULL, lastName TEXT NOT NULL, phone TEXT NOT NULL,"
							+ "email TEXT NOT NULL, mobile TEXT NOT NULL, phoneBusi TEXT NOT NULL, emailBusi TEXT NOT NULL,"
							+ "apartmentId TEXT REFERENCES apartment(apartmentId))");

			// Z�hlerexemplar = deviceUnit
			statement.executeUpdate("DROP TABLE IF EXISTS deviceUnit");
			statement.executeUpdate("CREATE TABLE deviceUnit (deviceID TEXT PRIMARY KEY, installedDate TEXT,"
					+ " apartmentId TEXT REFERENCES apartment(apartmentId), typeId TEXT REFERENCES deviceType(typeId))");

			// Mitarbeiter
			statement.executeUpdate("DROP TABLE IF EXISTS staff");
			statement.executeUpdate(
					"CREATE TABLE staff (staffId TEXT PRIMARY KEY, firstName TEXT, lastName TEXT, licencePlate TEXT, driverId TEXT, "
							+ "address TEXT, city TEXT, zip TEXT, birthday TEXT)");

			// Ablesehistorie
			statement.executeUpdate("DROP TABLE IF EXISTS readingHistory");
			statement.executeUpdate("CREATE TABLE readingHistory (readingId TEXT PRIMARY KEY, readingDate TEXT,"
					+ "countNow INTEGER, countDueDate INTEGER, dueDate TEXT, payed INTEGER, checkSum TEXT, deviceTest TEXT,"
					+ "deviceID TEXT REFERENCES deviceUnit(deviceID), staffId TEXT REFERENCES staff(staffId))");

			// Z�hlertyp
			statement.executeUpdate("DROP TABLE IF EXISTS deviceType");
			statement.executeUpdate("CREATE TABLE deviceType (typeId TEXT PRIMARY KEY, name TEXT, funk INTEGER)");


			// Bezirk
			statement.executeUpdate("DROP TABLE IF EXISTS region");
			statement.executeUpdate("CREATE TABLE region (name TEXT PRIMARY KEY, numberApartments INTEGER)");

			// Emlp_Bezirk
			statement.executeUpdate("DROP TABLE IF EXISTS staffRegion");
			statement.executeUpdate(
					"CREATE TABLE staffRegion (staffId TEXT REFERENCES staff(staffId), regionName TEXT REFERENCES region(name),"
							+ "PRIMARY KEY(staffId, regionName))");

			// Aufgaben
			statement.executeUpdate("DROP TABLE IF EXISTS task");
			statement.executeUpdate(
					"CREATE TABLE task (taskId TEXT PRIMARY KEY	, price TEXT, description TEXT, material TEXT, taskTime INTEGER NOT NULL)");

			// Termin
			statement.executeUpdate("DROP TABLE IF EXISTS appointment");
			statement.executeUpdate(
					"CREATE TABLE appointment (appointmentId TEXT PRIMARY KEY, status INTEGER, date TEXT, startTime TEXT, endTime TEXT,"
							+ " taskId TEXT REFERENCES task(taskId), customerNotes TEXT, count INTEGER,"
							+ "aptId TEXT REFERENCES apartment(apartmentId), staffId TEXT REFERENCES staff(staffId))");

			// Insert test data 
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt1', 'Hauptstrasse 3', 'EG links', 68167, 'Mannheim', 5, '', '0001')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt2', 'Am Markt 25', '2. OG rechts', 68167, 'Mannheim', 7, '', '0002')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt3', 'Am Markt 25', '2. OG links', 68167, 'Mannheim', 7, '', '0003')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt4', 'Bahnhofstra�e 167', 'EG links', 68167, 'Mannheim', 1, '', '0004')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt5', 'Bahnhofstra�e 167', 'EG rechts', 68167, 'Mannheim', 1, '', '0005')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt6', 'Bahnhofstra�e 167', '1. OG links', 68167, 'Mannheim', 1, '', '0006')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt7', 'Bahnhofstra�e 167', '1. OG rechts', 68167, 'Mannheim', 1, '', '0007')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt8', 'B�rgermeisterweg 12', '2. OG links', 68167, 'Mannheim', 4, '', '0008')"); 
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt9', 'Br�ggestra�e 84', 'EG links', 68167, 'Mannheim', 1, '', '0009')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt10', 'Br�ggestra�e 84', 'EG rechts', 68167, 'Mannheim', 1, '', '0010')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt11', 'Br�ggestra�e 84', '1. OG rechts', 68167, 'Mannheim', 1, '', '0011')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt12', 'Br�ggestra�e 84', '1. OG links', 68167, 'Mannheim', 1, '', '0012')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt13', 'Rosenweg 36', '2. OG rechts', 68167, 'Mannheim', 2, '', '0013')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt14', 'Petunienkoppel', '1. OG links', 68167, 'Mannheim', 1, '', '0014')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt15', 'Petunienkoppel', '1. OG rechts', 68167, 'Mannheim', 1, '', '0015')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt16', 'Goppeltweg 7', '2. OG links', 68167, 'Mannheim', 2, '', '0016')");
			
			
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0001', 'Peter', 'M�ller', '0621-293670', 'peter.m�ller@gmail.de', '0170-6983045', '', '', 'Apt1')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0002', 'Andrea', 'Schmidt', '0621-658034', 'andrea-schmidt@gmx.de', '0177-9031582', '', '', 'Apt2')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0003', 'Fritz', 'Meier', '0621-106792', 'frankmeier1@gmail.de', '0157-3690421', '', '', 'Apt3')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0004', 'Kerstin', 'Schulze', '0621-107389', 'k.schulze@hotmail.de', '0157-3485938', '', 'schulze@telekom.com', 'Apt4')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0005', 'Katrin', 'Meister', '0621-784927', 'kat.meister@outlook.de', '0157-8652186', '', '', 'Apt5')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0006', 'Klaus', 'Peters', '0621-6503957', 'k-peters@web.de', '0157-1569865', '', '', 'Apt6')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0007', 'Hella', 'Steinmetz', '0621-157712', 'hella.s@gmail.de', '0157-6821569', '', 'steinmetz@business.com', 'Apt7')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0008', 'Lisa', 'Franke', '0621-154356', 'Lisa1franke@gmx.de', '0157-98675421', '', '', 'Apt8')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0009', 'Holger', 'Martins', '0621-565656', 'holger123m@outlook.de', '0157-4379988', '0621 5689631', '', 'Apt9')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0010', 'Paul', 'Anderson', '0621-879963', 'anderson.peter@web.de', '0157-98698598', '0621 4578963', 'anderson@energieW.com', 'Apt10')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0011', 'Pia', 'M�nz', '0621-7843512', 'pia-muenz@gmail.de', '0157-5494515', '0621 5651560', 'muenz-gmbh@business.com', 'Apt11')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0012', 'Lena', 'Ludwig', '0621-555006', 'lelu94@gmx.de', '0157-64848475', '', '', 'Apt12')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0013', 'Kira', 'Landwehr', '0621-9532165', 'kira.landw@outlook.de', '0157-10203060', '', 'landwehr@garten.com', 'Apt13')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0014', 'Olaf', 'Jahnke', '0621-96325874', 'olaf.j@web.de', '0157-1457863', '', '', 'Apt14')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0015', 'Mia', 'Gregor', '0621-3216549', 'mia-gregor@gmail.de', '0157-6532908', '', 'gregor.mia@business.com', 'Apt15')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0016', 'Monika', 'Schuster', '0621-4568561', 'schuster.m@gmx.de', '0157-85649731', '', '', 'Apt16')");
		
			
			statement.executeUpdate(
					"INSERT INTO staff (staffId, firstName, lastName, licencePlate, driverId, address, city, zip, birthday)"
							+ "VALUES ('001', 'Markus', 'Kaufmann', 'MA-MA-123', 'F0100K85E37', 'Friedrichsring 12', 'Mannheim', 68167, '')");
			statement.executeUpdate(
					"INSERT INTO staff (staffId, firstName, lastName, licencePlate, driverId, address, city, zip, birthday)"
							+ "VALUES ('002', 'Frank', 'Fischer', 'MA-MA-456', 'H0020K31L49', 'D7 14', 'Mannheim', 68167, '')");


			statement.executeUpdate("INSERT INTO region (name, numberApartments) VALUES ('Bezirk 1', 126)");
			statement.executeUpdate("INSERT INTO region (name, numberApartments) VALUES ('Bezirk 2', 105)");

			statement.executeUpdate("INSERT INTO staffRegion (staffId, regionName) VALUES ('001', 'Bezirk 1')");
			statement.executeUpdate("INSERT INTO staffRegion (staffId, regionName) VALUES ('001', 'Bezirk 2')");

			statement.executeUpdate("INSERT INTO task (taskId, price, description, material, taskTime)"
					+ "VALUES ('002', '57.30', 'mittlere Z�hlerablesung', null, 30)");

			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00001', '2016-05-25', 'Apt1', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00002', '2016-05-25', 'Apt1', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00003', '2016-05-25', 'Apt1', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00004', '2016-05-25', 'Apt1', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00005', '2016-05-25', 'Apt1', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00006', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00007', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00008', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00009', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00010', '2018-01-17', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00011', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00012', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00013', '2016-03-22', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00014', '2016-03-22', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00015', '2017-03-22', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00016', '2017-03-17', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00017', '2017-03-17', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00018', '2016-03-22', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00019', '2016-03-22', 'Apt3', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00020', '2017-04-05', 'Apt4', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00021', '2016-04-05', 'Apt5', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00022', '2016-04-05', 'Apt6', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00023', '2016-04-05', 'Apt7', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00024', '2014-05-30', 'Apt8', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00025', '2014-05-30', 'Apt8', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00026', '2014-05-30', 'Apt8', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00027', '2014-05-30', 'Apt8', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00028', '2013-06-14', 'Apt9', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00029', '2014-02-16', 'Apt10', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00030', '2016-09-17', 'Apt11', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00031', '2012-03-09', 'Apt12', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00032', '2015-08-04', 'Apt13', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00033', '2015-08-04', 'Apt13', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00034', '2017-09-13', 'Apt14', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00035', '2016-04-28', 'Apt15', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00036', '2016-01-29', 'Apt16', '02')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00037', '2016-01-29', 'Apt16', '02')");

			statement.executeUpdate(
					"INSERT INTO deviceType (typeId, name, funk) VALUES ('01', 'Z�hler SIEMENS Bj. 2015', 0)");
			
			statement.executeUpdate(
					"INSERT INTO deviceType (typeId, name, funk) VALUES ('02', 'Z�hler QUNDIS Bj. 2014', 0)");

			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000001', 2, '2018-05-30', '12:00', '12:30', '002', '', 0, 'Apt1', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000002', 0, '', '', '', '002', 'Urlaub bis 30.05.2018', 0, 'Apt2', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000003', 0, '', '', '', '002', '', 0, 'Apt3', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000004', 2, '2018-05-30', '14:30', '15:00', '002', '', 1, 'Apt4', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000005', 2, '2018-05-30', '15:00', '15:30', '002', '', 1, 'Apt5', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000006', 2, '2018-05-25', '15:30', '16:00', '002', '', 1, 'Apt6', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000007', 2, '2018-05-30', '16:00', '16:30', '002', '', 1, 'Apt7', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000008', 2, '2018-05-31', '09:00', '09:30', '002', '', 0, 'Apt8', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000009', 2, '2018-06-01', '09:00', '09:30', '002', '', 0, 'Apt9', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000010', 2, '2018-06-01', '09:45', '10:15', '002', '', 0, 'Apt10', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000011', 2, '2018-06-01', '10:15', '10:45', '002', '', 0, 'Apt11', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000012', 2, '2018-05-31', '10:45', '11:15', '002', '', 0, 'Apt12', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000013', 0, '', '', '', '002', '', 0, 'Apt13', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000014', 0, '', '', '', '002', '', 0, 'Apt14', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000015', 0, '', '', '', '002', '', 0, 'Apt15', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000016', 2, '2018-06-04', '09:00', '09:30', '002', '', 0, 'Apt16', '001')");
			

			ResultSet result;

//			result = statement.executeQuery(
//					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
//							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
//							+ "JOIN task ON appointment.taskId = task.taskId WHERE date = '2018-05-19'");
			
//			result = statement.executeQuery(
//			"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
//					+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
//					+ "JOIN task ON appointment.taskId = task.taskId WHERE status = 0");
			
			result = statement.executeQuery(
			"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
					+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
					+ "JOIN task ON appointment.taskId = task.taskId WHERE (date >= '" + "2018-05-30" + "' AND status = 2)");
			
			
			JsonArray array = new JsonArray();
			JsonObject local;
			while (result.next()) {
				local = new JsonObject();
				local.addProperty("appointmentId:", result.getString("appointmentId"));
				local.addProperty("address:", result.getString("address"));
				local.addProperty("addition:", result.getString("addition"));
				local.addProperty("zip:", result.getInt("zip"));
				local.addProperty("city:", result.getString("city"));
				local.addProperty("counterNr:", result.getString("counterNr"));
				local.addProperty("manageId:", result.getString("manageId"));
				local.addProperty("customerId:", result.getString("customerId"));
				local.addProperty("date: ", result.getString("date"));
				local.addProperty("start: ", result.getString("startTime"));
				local.addProperty("customerName: ", result.getString("lastName"));
				local.addProperty("taskTime", result.getString("taskTime"));
				array.add(local);
			}
			for (int i = 0; i < array.size(); i++) {
				System.out.println(array.get(i));
			}

			// resultSet = statement.executeQuery("SELECT * from customer");
			// while (resultSet.next()) {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
