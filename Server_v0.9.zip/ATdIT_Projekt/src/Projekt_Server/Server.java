package Projekt_Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * The class server provides a server socket for communication with other clients
 * via the local network In the standard configuration the port 200 is used.
 * Remember if the port is changed, the clients have to change their connection
 * port as well, otherwise no connection is established.
 * 
 * The server will start a protocol (Protocol) which determines the
 * communication between client and server. This process will run infinitely and
 * can only be stopped by a fatal Java error or by manual termination.
 * 
 * @author D070700
 *
 */
class Server {

	private static ServerSocket server;

	public static void main(String[] args) {
		try {
			server = new ServerSocket(200);
			System.out.println("Server gestartet");		
			while (true) {
				Socket s = server.accept();
				new Protocol(s).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (RuntimeException e) { // catches Security and IAE Exceptions
			e.printStackTrace();
		}
	}
}