package Projekt_Server;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class CreateDB2_1 {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			Class.forName("org.sqlite.JDBC");

			Connection connection = DriverManager.getConnection("jdbc:sqlite:second.db");

			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30); // set timeout to 30 sec.

			// propmanage = Property management/ Hausverwaltung
			statement.executeUpdate("DROP TABLE IF EXISTS propManagement");
			statement.executeUpdate("CREATE TABLE propManagement (manageId TEXT PRIMARY KEY, email TEXT,"
					+ " phone TEXT, contactPerson TEXT, charges TEXT, companyName TEXT)");

			statement.executeUpdate("DROP TABLE IF EXISTS apartment");
			statement.executeUpdate("CREATE TABLE apartment (apartmentId TEXT PRIMARY KEY, address TEXT NOT NULL, addition TEXT NOT NULL,"
					+ "zip INTEGER NOT NULL, city TEXT NOT NULL, counterNr INTEGER NOT NULL, "
					+ "manageId TEXT REFERENCES propManagement(manageId), customerId TEXT REFERENCES customer(customerId))");

			statement.executeUpdate("DROP TABLE IF EXISTS customer");
			statement.executeUpdate(
					"CREATE TABLE customer (customerId TEXT PRIMARY KEY, firstName TEXT NOT NULL, lastName TEXT NOT NULL, phone TEXT NOT NULL,"
							+ "email TEXT NOT NULL, mobile TEXT NOT NULL, phoneBusi TEXT NOT NULL, emailBusi TEXT NOT NULL,"
							+ "apartmentId TEXT REFERENCES apartment(apartmentId))");

			// Z�hlerexemplar = deviceUnit
			statement.executeUpdate("DROP TABLE IF EXISTS deviceUnit");
			statement.executeUpdate("CREATE TABLE deviceUnit (deviceID TEXT PRIMARY KEY, installedDate TEXT,"
					+ " apartmentId TEXT REFERENCES apartment(apartmentId), typeId TEXT REFERENCES deviceType(typeId))");

			// Mitarbeiter
			statement.executeUpdate("DROP TABLE IF EXISTS staff");
			statement.executeUpdate(
					"CREATE TABLE staff (staffId TEXT PRIMARY KEY, firstName TEXT, lastName TEXT, licencePlate TEXT, driverId TEXT, "
							+ "address TEXT, city TEXT, zip TEXT, birthday TEXT)");

			// Ablesehistorie
			statement.executeUpdate("DROP TABLE IF EXISTS readingHistory");
			statement.executeUpdate("CREATE TABLE readingHistory (readingId TEXT PRIMARY KEY, readingDate TEXT,"
					+ "countNow INTEGER, countDueDate INTEGER, dueDate TEXT, payed INTEGER, checkSum TEXT, deviceTest TEXT,"
					+ "deviceID TEXT REFERENCES deviceUnit(deviceID), staffId TEXT REFERENCES staff(staffId))");

			// Z�hlertyp
			statement.executeUpdate("DROP TABLE IF EXISTS deviceType");
			statement.executeUpdate("CREATE TABLE deviceType (typeId TEXT PRIMARY KEY, name TEXT, funk INTEGER)");

			// checked

			// Bezirk
			statement.executeUpdate("DROP TABLE IF EXISTS region");
			statement.executeUpdate("CREATE TABLE region (name TEXT PRIMARY KEY, numberApartments INTEGER)");

			// Emlp_Bezirk
			statement.executeUpdate("DROP TABLE IF EXISTS staffRegion");
			statement.executeUpdate(
					"CREATE TABLE staffRegion (staffId TEXT REFERENCES staff(staffId), regionName TEXT REFERENCES region(name),"
							+ "PRIMARY KEY(staffId, regionName))");

			// Aufgaben
			statement.executeUpdate("DROP TABLE IF EXISTS task");
			statement.executeUpdate(
					"CREATE TABLE task (taskId TEXT PRIMARY KEY	, price TEXT, description TEXT, material TEXT, taskTime INTEGER NOT NULL)");

			// Termin
			statement.executeUpdate("DROP TABLE IF EXISTS appointment");
			statement.executeUpdate(
					"CREATE TABLE appointment (appointmentId TEXT PRIMARY KEY, status INTEGER, date TEXT, startTime TEXT, endTime TEXT,"
							+ " taskId TEXT REFERENCES task(taskId), customerNotes TEXT, count INTEGER,"
							+ "aptId TEXT REFERENCES apartment(apartmentId), staffId TEXT REFERENCES staff(staffId))");

			// Insert test data
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt1', 'Hauptstrasse 3', '', 68167, 'Mannheim', 5, '', '0001')");
			statement.executeUpdate(
					"INSERT INTO apartment (apartmentId, address, addition, zip, city, counterNr, manageId, customerId)"
							+ "VALUES ('Apt2', 'Am Markt 25', '2. OG', 68167, 'Mannheim', 7, '', '0003')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0001', 'Peter', 'M�ller', '0621-293670', 'peter.m�ller@gmail.de', '0170-6983045', '', '', 'Apt1')");
			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0002', 'Andrea', 'Schmidt', '0621-658034', 'andrea-schmidt@gmx.de', '0177-9031582', '', '', 'Apt2')");

			statement.executeUpdate(
					"INSERT INTO customer (customerId, firstName, lastName, phone, email, mobile, phoneBusi, emailBusi, apartmentId)"
							+ "VALUES ('0003', 'Frank', 'Meier', '0621-106792', 'frankmeier1@gmail.de', '0157-3690421', '', '', 'Apt3')");

			statement.executeUpdate(
					"INSERT INTO staff (staffId, firstName, lastName, licencePlate, driverId, address, city, zip, birthday)"
							+ "VALUES ('001', 'Markus', 'Kaufmann', 'MA-MA-123', '7H31LX9W', 'Friedrichsring 12', 'Mannheim', 68167, '')");

			statement.executeUpdate("INSERT INTO region (name, numberApartments) VALUES ('Bezirk 1', 126)");
			statement.executeUpdate("INSERT INTO region (name, numberApartments) VALUES ('Bezirk 2', 105)");

			statement.executeUpdate("INSERT INTO staffRegion (staffId, regionName) VALUES ('001', 'Bezirk 1')");
			statement.executeUpdate("INSERT INTO staffRegion (staffId, regionName) VALUES ('001', 'Bezirk 2')");

			statement.executeUpdate("INSERT INTO task (taskId, price, description, material, taskTime)"
					+ "VALUES ('002', '57.30', 'mittlere Z�hlerablesung', null, 30)");

			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00001', '2016-05-25', 'Apt1', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00002', '2016-05-25', 'Apt1', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00003', '2016-05-25', 'Apt1', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00004', '2016-05-25', 'Apt1', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00005', '2016-05-25', 'Apt1', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00006', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00007', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00008', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00009', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00010', '2018-01-17', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00011', '2016-03-22', 'Apt2', '01')");
			statement.executeUpdate("INSERT INTO deviceUnit (deviceId, installedDate, apartmentId, typeId)"
					+ "VALUES('00012', '2016-03-22', 'Apt2', '01')");

			statement.executeUpdate(
					"INSERT INTO deviceType (typeId, name, funk) VALUES ('01', 'Z�hler SIMENNS Bj. 2015', 0)");

			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000001', 2, '2018-06-08', '09:00', '09:30', '002', '', 0, 'Apt1', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000002', 0, '', '', '', '002', '', 0, 'Apt1', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000004', 2, '2018-05-26', '09:00', '09:30', '002', '', 1, 'Apt1', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000006', 0, '', '', '', '002', '', 0, 'Apt2', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000007', 2, '2018-05-26', '23:30', '10:30', '002', '', 1, 'Apt2', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000009', 0, '', '', '', '002', '', 0, 'Apt2', '001')");
			statement.executeUpdate(
					"INSERT INTO appointment(appointmentId, status, date, startTime, endTime, taskId, customerNotes,"
							+ "count, aptId, staffId) VALUES ('000010', 2, '2018-06-08', '10:00', '10:30', '002', '', 0, 'Apt1', '001')");

			ResultSet result;

//			result = statement.executeQuery(
//					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
//							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
//							+ "JOIN task ON appointment.taskId = task.taskId WHERE date = '2018-05-19'");
			
//			result = statement.executeQuery(
//			"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
//					+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
//					+ "JOIN task ON appointment.taskId = task.taskId WHERE status = 0");
			
			result = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId) "
							+ "JOIN task ON appointment.taskId = task.taskId WHERE appointmentId = '" + "000006"
							+ "' AND status = 0");
			
			JsonArray array = new JsonArray();
			JsonObject local;
			while (result.next()) {
				local = new JsonObject();
				local.addProperty("appointmentId:", result.getString("appointmentId"));
				local.addProperty("address:", result.getString("address"));
				local.addProperty("addition:", result.getString("addition"));
				local.addProperty("zip:", result.getInt("zip"));
				local.addProperty("city:", result.getString("city"));
				local.addProperty("counterNr:", result.getString("counterNr"));
				local.addProperty("manageId:", result.getString("manageId"));
				local.addProperty("customerId:", result.getString("customerId"));
				local.addProperty("date: ", result.getString("date"));
				local.addProperty("start: ", result.getString("startTime"));
				local.addProperty("customerName: ", result.getString("lastName"));
				local.addProperty("taskTime", result.getString("taskTime"));
				array.add(local);
			}
			for (int i = 0; i < array.size(); i++) {
				System.out.println(array.get(i));
			}

			// resultSet = statement.executeQuery("SELECT * from customer");
			// while (resultSet.next()) {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
