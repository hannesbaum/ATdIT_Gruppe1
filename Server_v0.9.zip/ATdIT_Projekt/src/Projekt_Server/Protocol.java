package Projekt_Server;

import java.net.Socket;
import java.sql.*;
import java.time.*;
import java.util.*;
import java.io.*;

import com.google.gson.*;

/**
 * The class Protocol provides a protocol according to which the server and
 * client communicate with each other In here, different communications are
 * analyzed and corresponding actions are taken like DB-queries and DB-updates
 * This class might throw different exeptions such as IOExceptions,
 * SQLExceptions and other RuntimeExceptions as IAEs
 * 
 * To transfer data via the network, serialization is used. In this scenario,
 * the data can be only an instance of an object that both classes know.
 * Therefore, one cannot transfer custom datatypes, because they are not
 * explictly known to both sides. To solve this problem, the database results
 * are transfered into JSON Objects and stored in a JSON array. This array
 * (represented by "com.google.gson.JsonArray") is transfered to the client and
 * will be "decoded" back into a usable object.
 * 
 * @author D070700
 *
 */
public class Protocol extends Thread {
	private Socket socket; // Socket from the client
	private ObjectInputStream fromClient; // inputStream from Client
	private ObjectOutputStream toClient; // OutputStream to Client
	private int nr = 0;
	private static int count = 0;
	private ResultSet resultSet; // resultSet for DB queries
	private JsonObject jsonObject = new JsonObject();
	private JsonArray jsonArray = new JsonArray();
	private String userInput = "", transferToClient = "";
	private Connection connection = null; // connection to database
	private Statement statement = null; // object needed to execute SQL orders
	private Gson gson = new Gson(); // object used for data serialization

	/**
	 * Basic constructor for the AuskunftProtocol which takes a socket as a
	 * parameter
	 * 
	 * @param s
	 *            - Socket s which establishes the connection between Server/client
	 * @throws ClassNotFoundException
	 *             - is thrown if required sqlite references are not found
	 */
	public Protocol(Socket s) {
		try {
			this.socket = s;
			nr = ++count;
			fromClient = new ObjectInputStream(s.getInputStream());
			toClient = new ObjectOutputStream(s.getOutputStream());
		} catch (IOException e) {
			System.out.println("Error bei Client " + nr);
			e.printStackTrace();
		}
	}

	/**
	 * The run method is overwritten, due to the fact that AuskunftProtocol extends
	 * Thread In here, the database connection is established and the communication
	 * from the client is analyzed Based on the input from the client, SQL queries
	 * or database updates are executed
	 */
	public void run() {
		try {
			// only perform if the socket is not closed;
			// the socket should however be closed
			// after every data exchange
			if (!socket.isClosed()) {
				toClient.writeObject("Connection established");
				userInput = (String) fromClient.readObject();

				// create a database connection
				// Syntax: "jdbc:sqlite:<<database_Name.db>>"
				connection = DriverManager.getConnection("jdbc:sqlite:second.db");
				statement = connection.createStatement();
				if (userInput.equalsIgnoreCase("query")) {
					basicQuery(); // SQL query for all appointments today
				} else if (userInput.equalsIgnoreCase("undated")) {
					undatedQuery(); // SQL query for all undated appointments
				} else if (userInput.equalsIgnoreCase("schedule")) {
					scheduleAppointment(); // SQL update to schedule a certain appointment
				} else if (userInput.equalsIgnoreCase("updateData")) {
					updateCounterHistory();
				} else if (userInput.equalsIgnoreCase("getCounters")) {
					getCounterNumber();
				}
				socket.close(); // closes the client socket
			}
		} catch (SQLException e) {
			// probably: db connection not available
			System.err.println("Error: Database not found");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Error at ObjectOutputStream: IOException");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// thrown from ObjectInputStream
			System.err.println("Error at ObjectOutputStream: ClassNotFoundException");
			e.printStackTrace();
		}
	}

	/**
	 * This method prints the counterNumber to an existing apartment into the
	 * outputStream
	 */
	private void getCounterNumber() {
		try {
			String appointmentId = (String) fromClient.readObject();
			appointmentId = formatString(appointmentId);

			resultSet = statement.executeQuery(
					"SELECT counterNr FROM apartment JOIN appointment ON apartment.apartmentId = appointment.aptId"
							+ " WHERE appointmentId = '" + appointmentId + "'");

			while (resultSet.next()) {
				jsonObject = new JsonObject();
				jsonObject.addProperty("counterNr", resultSet.getString("counterNr"));
				jsonArray.add(jsonObject);
			}
			transferToClient = gson.toJson(jsonArray);
			System.out.println(transferToClient); // control output what is being transfered to the client
			toClient.writeObject(transferToClient);
		} catch (SQLException e) {
			System.err.println("SQL Exception: error at retreive counter number");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Error at ObjectOutputStream: IOException");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.err.println("Error at ObjectOutputStream: ClassNotFoundException");
			e.printStackTrace();
		}
	}

	/**
	 * This method updated the reading history based on the data in the inputStream
	 */
	private void updateCounterHistory() {
		try {
			JsonArray newData = new JsonArray();
			Gson gson = new Gson();
			String inputString = (String) fromClient.readObject();
			newData = gson.fromJson(inputString, JsonArray.class);
			System.out.println(inputString);
			/**
			 * The data saving to the database based on the input is not programmed in this
			 * demo version of the server
			 */

		} catch (ClassNotFoundException e) {
			System.err.println("Error at OutputStream: ClassNotFoundException");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Error at Stream: IOException");
			e.printStackTrace();
		}
	}

	/**
	 * This method implements the logic to find the next free timeslot if an
	 * unscheduled appointment is supposed to be scheduled Therefore, all active
	 * appointments are analyzed and the toBeDated-appointment is shifted according
	 * to the next free slot. In this scenario, weekends are non-working days. In
	 * addition, appointments are only placed between 9:00 am and 4:30 pm (normal
	 * working hours)
	 * 
	 * @param appointmentList
	 *            - List<Appointment> - should contain all scheduled appointments
	 * @param toBeDated
	 *            - Appointment - the appointment which should be scheduled
	 * @return - String - "success" if the appointment could be dated; "" if no free
	 *         slot was found
	 */
	private String findDateTime(List<Appointment> appointmentList, Appointment toBeDated) {
		try {
			LocalTime startWork = LocalTime.of(9, 0), endWork = LocalTime.of(16, 30);
			if (appointmentList.size() != 0) {
				for (Appointment currentAppointment : appointmentList) {
					if (toBeDated.getDate().isBefore(currentAppointment.getDate())) {
						return "success";
					}

					// here we need to find a free timeslot on that exact day!!
					else if (currentAppointment.getDate().equals(toBeDated.getDate())) {

						// if the EndTime of the toBeDated Object + 15 minutes buffer time is before
						// the startTime of the next appointment
						if (toBeDated.getEnd().plusMinutes(15).isBefore(currentAppointment.getStart())) {
							return "success";
						}

						// if any collusion between the toBeDated-Appointment and
						// already existent appointments occur; change the time of the
						// toBeDated-Appointment
						// examples of overlapping: same starttime, same endtime, overlapping start
						// and/or endtime
						if ((toBeDated.getStart().isAfter(currentAppointment.getStart())
								&& toBeDated.getEnd().isBefore(currentAppointment.getEnd()))
								|| toBeDated.getStart().equals(currentAppointment.getStart())
								|| toBeDated.getEnd().equals(currentAppointment.getEnd())
								|| (toBeDated.getStart().isBefore(currentAppointment.getStart())
										&& toBeDated.getEnd().plusMinutes(15).isAfter(currentAppointment.getStart()))
								|| (currentAppointment.getStart().isBefore(toBeDated.getStart()) && currentAppointment
										.getEnd().plusMinutes(15).isAfter(currentAppointment.getStart()))) {

							toBeDated.setStart(currentAppointment.getEnd().plusMinutes(15));

							// if you move into the endWork phase where the employee finishes working, skip
							// to the next day (not SAT/SUN) and reset time to 9am
							if (toBeDated.getStart().isAfter(endWork)) {
								if (toBeDated.getDate().getDayOfWeek() == DayOfWeek.FRIDAY) {
									toBeDated.setDate(toBeDated.getDate().plusDays(3));
								} else {
									toBeDated.setDate(toBeDated.getDate().plusDays(1));
								}
								toBeDated.setStart(startWork);
							}
						}
					}
				}
				return "success";
			} else {
				// list is empty, leave standard configuration
				return "success";
			}
		} catch (NullPointerException e) {
			System.err.println("NullPointerException occured");
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * The basicQuery() method executes a SQL query for the appointments scheduled
	 * for today and returns those to the client To transport the data to the
	 * client, the query results are transformed into JsonObjects and saved in a
	 * JsonArray. This data can then be serialized and be sent to the client via a
	 * ObjectOutputStream
	 */
	private void basicQuery() {
		try {
			LocalDate today = LocalDate.now();
			LocalTime now = LocalTime.now();
			now = now.minusMinutes(30); // 30 minutes ago; do not display appointments which are older than that
			String formatNow, nowHour, nowMinute;

			if (now.getHour() < 10)
				nowHour = "0" + now.getHour();
			else
				nowHour = "" + now.getHour();
			if (now.getMinute() < 10)
				nowMinute = "0" + now.getMinute();
			else
				nowMinute = "" + now.getMinute();

			formatNow = nowHour + ":" + nowMinute;
			String todayStr = today.toString();

			// all Appointments from today
			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId) "
							+ "JOIN task ON appointment.taskId = task.taskId WHERE date = '" + todayStr
							+ "' AND startTime >= '" + formatNow + "' ORDER BY startTime");

			while (resultSet.next()) {
				jsonObject = new JsonObject();
				jsonObject.addProperty("firstName", resultSet.getString("firstName"));
				jsonObject.addProperty("lastName", resultSet.getString("lastName"));
				jsonObject.addProperty("address", resultSet.getString("address"));
				jsonObject.addProperty("addition", resultSet.getString("addition"));
				jsonObject.addProperty("zip", resultSet.getString("zip"));
				jsonObject.addProperty("city", resultSet.getString("city"));
				jsonObject.addProperty("counterNr:", resultSet.getString("counterNr"));
				jsonObject.addProperty("phone", resultSet.getString("phone"));
				jsonObject.addProperty("notes", resultSet.getString("customerNotes"));
				jsonObject.addProperty("email", resultSet.getString("email"));
				jsonObject.addProperty("mobile", resultSet.getString("mobile"));
				jsonObject.addProperty("phoneBusi", resultSet.getString("phoneBusi"));
				jsonObject.addProperty("emailBusi", resultSet.getString("emailBusi"));
				jsonObject.addProperty("start", resultSet.getString("startTime"));
				jsonObject.addProperty("duration", resultSet.getString("taskTime"));
				jsonObject.addProperty("id", resultSet.getString("appointmentId"));
				jsonArray.add(jsonObject);
			}
			transferToClient = gson.toJson(jsonArray);
			System.out.println(transferToClient); // control output what is being transfered to the client
			toClient.writeObject(transferToClient);
		} catch (SQLException e) {
			// probable database error or timeout; sent an empty array to the client
			try {
				transferToClient = "";
				toClient.writeObject(transferToClient);
			} catch (IOException ioe) {
				// thrown by OutputStream
				System.err.println("Error at ObjectOutputStream: IOException");
				ioe.printStackTrace();
			}
		} catch (IOException e) {
			// thrown by OutputStream,
			System.err.println("Error at ObjectOutputStream: IOException");
			e.printStackTrace();
		}
	}

	/**
	 * The undatedQuery() method executes a SQL query for the appointments which are
	 * not scheduled yet. The data formatting and transportation to the client is
	 * similar to the basicQuery() method. Read the basicQuery() documentation for
	 * further information
	 */
	private void undatedQuery() {
		try {
			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "JOIN task ON appointment.taskId = task.taskId WHERE status = 0");
			while (resultSet.next()) {
				jsonObject = new JsonObject();
				jsonObject.addProperty("firstName", resultSet.getString("firstName"));
				jsonObject.addProperty("lastName", resultSet.getString("lastName"));
				jsonObject.addProperty("address", resultSet.getString("address"));
				jsonObject.addProperty("addition", resultSet.getString("addition"));
				jsonObject.addProperty("zip", resultSet.getString("zip"));
				jsonObject.addProperty("city", resultSet.getString("city"));
				jsonObject.addProperty("counterNr:", resultSet.getString("counterNr"));
				jsonObject.addProperty("phone", resultSet.getString("phone"));
				jsonObject.addProperty("notes", resultSet.getString("customerNotes"));
				jsonObject.addProperty("email", resultSet.getString("email"));
				jsonObject.addProperty("mobile", resultSet.getString("mobile"));
				jsonObject.addProperty("phoneBusi", resultSet.getString("phoneBusi"));
				jsonObject.addProperty("emailBusi", resultSet.getString("emailBusi"));
				jsonObject.addProperty("start", resultSet.getString("startTime"));
				jsonObject.addProperty("duration", resultSet.getString("taskTime"));
				jsonObject.addProperty("id", resultSet.getString("appointmentId"));
				jsonArray.add(jsonObject);
			}
			transferToClient = gson.toJson(jsonArray);
			System.out.println(transferToClient); // control output what is being transfered to the client
			toClient.writeObject(transferToClient);

		} catch (SQLException e) {
			// probable database error or timeout; sent an empty array to the client
			try {
				toClient.writeObject(new JsonArray());
			} catch (IOException ioe) {
				// thrown by OutputStream
				System.err.println("Error at ObjectOutputStream: IOException");
				ioe.printStackTrace();
			}
		} catch (IOException e) {
			// thrown by OutputStream
			System.err.println("Error at ObjectOutputStream: IOException");
			e.printStackTrace();
		}
	}

	/**
	 * The scheduleApt() method receives an appointmentId from the client (an
	 * undated appointment) and finds a valid timeslot for the appointment by
	 * calling the findDateTime() method The result of the findDateTime() method is
	 * passed to the client
	 */
	private void scheduleAppointment() {
		try {
			// connection = DriverManager.getConnection("jdbc:sqlite:second.db");
			// statement = connection.createStatement();
			String appointmentID = (String) fromClient.readObject();
			LocalDateTime now = LocalDateTime.now();
			LocalDate inTwoWeeks = now.toLocalDate().plusWeeks(2);
			LocalTime startWork = LocalTime.of(9, 0);
			Appointment toBeDated, existingAppointment;
			List<Appointment> appointmentList = new LinkedList<>(); // store query results
			toBeDated = new Appointment();
			LocalDate today = now.toLocalDate();
			appointmentID = formatString(appointmentID);

			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId) "
							+ "JOIN task ON appointment.taskId = task.taskId WHERE appointmentId = '" + appointmentID
							+ "' AND status = 0");

			if (resultSet.next()) {
				toBeDated = new Appointment(resultSet.getString("appointmentId"), today.toString(), "00:00", "09:00",
						resultSet.getString("taskId"), resultSet.getInt("taskTime"), resultSet.getInt("status"));

				if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SATURDAY)
					inTwoWeeks = inTwoWeeks.plusDays(2);
				if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SUNDAY)
					inTwoWeeks = inTwoWeeks.plusDays(1);
				toBeDated.setDate(inTwoWeeks);
				toBeDated.setStart(startWork);

				resultSet = statement.executeQuery(
						"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
								+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
								+ "JOIN task ON appointment.taskId = task.taskId WHERE (date >= '"
								+ inTwoWeeks.toString() + "' AND status = 2)");

				while (resultSet.next()) {
					existingAppointment = new Appointment(resultSet.getString("appointmentId"),
							resultSet.getString("date"), resultSet.getString("startTime"),
							resultSet.getString("endTime"), resultSet.getString("taskId"),
							Integer.valueOf(resultSet.getString("taskTime")),
							Integer.valueOf(resultSet.getString("status")));
					appointmentList.add(existingAppointment);
				}

				String result = findDateTime(appointmentList, toBeDated);
				if (result == "success") {
					// set status to active
					System.out.println("Before Update: " + toBeDated);
					String newDate = toBeDated.getDate().toString();
					String newStartTime = toBeDated.getStart().toString();
					String newEndTime = toBeDated.getEnd().plusMinutes(toBeDated.getTaskTime()).toString();
					statement.executeUpdate(
							"UPDATE appointment SET status = 2 WHERE appointmentId = '" + appointmentID + "'");
					statement.executeUpdate("UPDATE appointment SET startTime = '" + newStartTime
							+ "' WHERE appointmentId = '" + appointmentID + "'");
					statement.executeUpdate("UPDATE appointment SET endTime = '" + newEndTime
							+ "' WHERE appointmentId = '" + appointmentID + "'");
					statement.executeUpdate("UPDATE appointment SET date = '" + newDate + "' WHERE appointmentId = '"
							+ appointmentID + "'");
					String dateAndTime = toBeDated.getDate().toString() + " " + toBeDated.getStart().toString()
							+ " Uhr";
					System.out.println("Result from toBeDated: " + dateAndTime);
					toClient.writeObject("Termin best�tigt f�r: " + dateAndTime);
					resultSet = statement
							.executeQuery("SELECT * FROM appointment WHERE appointmentId = '" + appointmentID + "'");
					System.out.println("After Update: Id: " + appointmentID);
					if (resultSet.next()) {
						System.out.println(resultSet.getString("appointmentId") + "; " + resultSet.getString("status"));
						System.out.println(resultSet.getString("date") + "; " + resultSet.getString("startTime") + "; "
								+ resultSet.getString("endTime"));
						System.out.println("Default: " + newDate + "; " + newStartTime + "; " + newEndTime);
					}
					statement.close();
				} else {
					toClient.writeObject("failedApt");
				}
			}
		} catch (IOException e) {
			System.err.println("Error at ObjectOutputStream: IOException");
			e.printStackTrace();
		} catch (SQLException e) {
			// posible db error, return error code
			try {
				toClient.writeObject("failedSQL");
			} catch (IOException ioe) {
				System.err.println("Error at ObjectOutputStream: IOException");
				ioe.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			System.err.println("Error at ObjectOutputStream: Class not fround Exception");
			e.printStackTrace();
		}
	}

	/**
	 * Formats strings which have additional " - characters
	 * 
	 * @param str
	 *            - String to be formatted
	 * @return - String - the formatted string
	 */
	private String formatString(String str) {
		StringBuilder builder = new StringBuilder(str);
		if (builder.charAt(0) == '\"')
			builder.deleteCharAt(0);
		if (builder.charAt(builder.length() - 1) == '\"')
			builder.deleteCharAt(builder.length() - 1);
		return builder.toString();
	}
}
