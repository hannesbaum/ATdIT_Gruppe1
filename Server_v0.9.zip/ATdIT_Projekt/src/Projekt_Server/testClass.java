package Projekt_Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class testClass {

	public static void main(String[] args) {
		Connection connection = null; // connection to database
		Statement statement = null; // object needed to execute SQL orders
		ResultSet resultSet; // resultSet for DB queries
		try {
			connection = DriverManager.getConnection("jdbc:sqlite:second.db");
			statement = connection.createStatement();

			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "WHERE status = 2");
			
			

			while (resultSet.next()) {
				System.out.print("ID: " + resultSet.getString("appointmentId"));
				System.out.print(" Status: " + resultSet.getString("status"));
				System.out.print(" Date: " + resultSet.getString("date"));
				System.out.println(" Time: " + resultSet.getString("startTime"));
			}
			System.out.println("done");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
