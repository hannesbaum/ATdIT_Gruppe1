package ServerTest;

import static org.junit.Assert.assertTrue;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import org.junit.Before;
import org.junit.Test;


/**
 * Tests if the basic query method of the Server protocol provides an answer
 * Because the database can change on a very frequent basis, no exact data similarities can be checked, only the 
 * fact if a correct object is returned via the network
 * @author D070700
 *
 */
public class ProtocolBasicQueryTest {

	private Socket socket;
	private ObjectInputStream fromServer;
	private ObjectOutputStream toServer;
	
	
	@Before
	public void init() throws Exception{
		socket = new Socket("localhost", 200);
		toServer = new ObjectOutputStream(socket.getOutputStream());
		fromServer = new ObjectInputStream(socket.getInputStream());
	}
	
	@Test
	public void testBasicQuery() throws Exception{
		toServer.writeObject("query");
		String connectionStatus = (String)fromServer.readObject();
		assertTrue(connectionStatus.equals("Connection established"));
		Object local = fromServer.readObject();
		assertTrue(local instanceof String);	//value should always be a string due to the serialization
	}	
}