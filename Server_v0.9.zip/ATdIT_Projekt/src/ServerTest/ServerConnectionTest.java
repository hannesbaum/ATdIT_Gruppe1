package ServerTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import org.junit.jupiter.api.Test;

/**
 * This test will check if a connection to the server can be established. 
 * For this test to work, the server has to run and the port numbers have to be identical.
 * @author D070700
 *
 */
public class ServerConnectionTest {

	@Test
	/**
	 * Testing if a connection to the server can be established. Make sure the port
	 * numbers in the server and client applications are the same!
	 * 
	 * @throws Exception
	 */
	public void connectToServer() throws Exception {
		Socket socket = new Socket("localhost", 200);
		ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
		ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());
		assertEquals((String) fromServer.readObject(), "Connection established");
		socket.close();
	}
}