package AppointmentTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.*;

import Projekt_Server.Appointment;

import java.time.*;

public class AppointmentConstructorTest {
	Appointment local;
	
	@Test
	public void generateWithValidData() throws Exception{
		local = new Appointment("01", "2018-06-04", "09:00", "09:30", "01", 30, 0);
		assertNotNull(local);
		assertTrue(local.getAppointID() == "01");
		assertTrue(local.getDate().equals(LocalDate.of(2018, 06, 04)));
		assertTrue(local.getStart().equals(LocalTime.of(9, 0)));
		assertTrue(local.getEnd().equals(LocalTime.of(9, 30)));
		assertTrue(local.getTaskID() == "01");
		assertTrue(local.getStatus() == 0);
	}
	
	@Test
	public void generateWithoutValidDate() throws Exception{
		assertThrows(IllegalArgumentException.class, () -> {
			local = new Appointment("01", "", "09:00", "09:30", "01", 30, 0);
		});
		
		assertThrows(IllegalArgumentException.class, () -> {
			local = new Appointment("01", null, "09:00", "09:30", "01", 30, 0);
		});
	}
	
	@Test
	public void generateWithoutValidTime() throws Exception{
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", "", "09:30", "01", 30, 0);
		});
		
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", null, "09:30", "01", 30, 0);
		});
		
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", "9:00", "09:30", "01", 30, 0);
		});
		
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", "09:00", "9:30", "01", 30, 0);
		});
	}
	
	@Test
	public void generateWithoutValidStatusCode() throws Exception{
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", "09:30", "09:30", "01", 30, 1);
		});
		
		assertThrows(IllegalArgumentException.class, () ->{
			local = new Appointment("01", "2018-06-04", "09:30", "09:30", "01", 30, 4);
		});
	}
}
