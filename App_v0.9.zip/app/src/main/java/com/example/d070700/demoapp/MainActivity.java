package com.example.d070700.demoapp;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentTransaction;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.example.d070700.demoapp.R.*;

/**
 * This app is a demonstration how to simplify the job of a "Zählungsableser für Heizungen"
 * In detail, this app provides an user interface to have all the necessary information in one place
 * First, it provides a simple overview of the upcoming appointments and makes them easily accessible.
 * Secondy, it has an easy-to-use contact interface which allows to contact the customerAppointments with as
 * little effort as possible.
 * Furthermore, future appointments can be scheduled within the app and reading values can be
 * recorded and will be sent to the server.
 */
public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    // API requirement is necessary because LocalDateTime is only available since Java 8
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // default implementation; savedInstanceState deals with active activities and how they are handled
        if (savedInstanceState == null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            RecyclerViewFragment fragment = new RecyclerViewFragment();
            transaction.replace(id.sample_content_fragment, fragment, "recyclerView");
            transaction.commit();
        }
        // localJsonArray method to set the current date
        refreshHeadline();
        Toolbar toolbar = findViewById(id.toolbar);
        setSupportActionBar(toolbar);

        // drawer layout is referring to the left side layout
        DrawerLayout drawer = findViewById(id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    /**
     * This method is part of the lifecycle of a view and will be called if the frame is resumed
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onResume() {
        refreshHeadline();
        super.onResume();
    }

    /**
     * This method constructs the next fragment based on the button pressed
     *
     * @param transfer - String which should identify the pressed button
     * @param customer - forward the customerAppointment, from which the Action originated to display customized data
     */
    protected void transferButtons(String transfer, CustomerAppointment customer) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        switch (transfer) {
            case "contact":
                if (customer != null) {
                    ContactFragment contactFragment = new ContactFragment();
                    contactFragment.setCustomerAppointment(customer);
                    transaction.replace(id.sample_content_fragment, contactFragment, transfer);
                }
                break;
            case "detail":
                if (customer != null) {
                    DetailPaneFragment detailFragment = new DetailPaneFragment();
                    detailFragment.setCustomerAppointment(customer);
                    transaction.replace(id.sample_content_fragment, detailFragment, transfer);
                }
                break;
            case "editData":
                /*
                Not included in this demo version
                This button should lead to a page, where old inputs can be changed if an error occurs
                */
                break;
        }
        // system procedures to follow the "standard fragment changing" operations
        transaction.addToBackStack(transfer);
        transaction.commit();
    }

    /**
     * This method creates new data input fragments based on the amount of devices in the customerAppointment's apartment
     *
     * @param count - int - the amount of devices which input shall be recorded
     */
    protected void setDataTransfer(int count) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        DataInputFragment inputFragment = new DataInputFragment();
        inputFragment.resetCount();
        inputFragment.setDeviceCount(count);
        transaction.replace(id.sample_content_fragment, inputFragment, "setData1");
        transaction.addToBackStack("setData1");
        transaction.commit();
    }

    /**
     * Overwritten method which will check if the main activity header has to be changed; super() will be called
     * Requires API because of LocalDateTime is only available since Java 8
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBackPressed() {
        //close an open drawer menu if back is pressed
        DrawerLayout drawer = findViewById(id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    /**
     * Standard implementation for creating the Options Menu
     * This method is called by the framework and does not have to be called manually
     *
     * @param menu - a menu object
     * @return - true as a default return value
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    /**
     * This method deals with a selected item from the Options menu
     * In this demo version, only a placeholder was set which is not based on any functionality
     * This method is called by the framework and therefore does not have to be called separately
     *
     * @param item - The MenuItem which was pressed
     * @return boolean - returns the success of the super method
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }


    /**
     * This method chooses a following action based on the pressed button on the navigation drawer
     * This method is called by the framework and therefore does not have to be called separately
     *
     * @param item - The navigation drawer will submit the element which has been pressed
     * @return - true as a default return value
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // start fragment
            goHome(item);
        } else if (id == R.id.nav_calendar) {
            goCalendar();
        } else if (id == R.id.nav_settings) {
            // settings fragment
            goSettings();
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);        // closes drawer if new item has been selected
        return true;
    }


    /**
     * This method places the current date in the headline textbox
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void refreshHeadline() {
        TextView date = findViewById(R.id.textView2);       // "headline" textview which is part of the main activity
        LocalDateTime local = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd.MM.");  // date format: Weekday, Day, Month
        date.setText(local.format(formatter));
    }

    /**
     * Resetting the shown fragment back to the main fragment if the menu-item "Home" is pressed
     * Requires API because LocalDateTime is only available since Java 8
     *
     * @param item - will pass on the pressed item
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void goHome(MenuItem item) {
        // the whole backstack is deleted, as soon as you go home; pressing back again will close the app
        for (int i = getSupportFragmentManager().getBackStackEntryCount(); i > 0; i--) {
            getSupportFragmentManager().popBackStack();
        }
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        RecyclerViewFragment recyclerView = new RecyclerViewFragment();
        transaction.replace(id.sample_content_fragment, recyclerView, "recyclerView");
        transaction.addToBackStack("recyclerView");
        transaction.commit();
        DrawerLayout drawer = findViewById(id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    /**
     * Setting the visible fragment to the calendar fragment
     */
    private void goCalendar() {
        DrawerLayout drawer = findViewById(id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START))
            drawer.closeDrawer(GravityCompat.START);
        for (int i = getSupportFragmentManager().getBackStackEntryCount(); i > 0; i--) {
            getSupportFragmentManager().popBackStack();
        }
        TextView localTextView = findViewById(R.id.textView2);
        localTextView.setText("Termine verwalten");     //headline is changed
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        UnscheduledFragment calendar = new UnscheduledFragment();
        transaction.replace(id.sample_content_fragment, calendar, "calendar");
        transaction.addToBackStack("calendar");
        transaction.commit();
    }

    /**
     * Changes the visible fragment to the settings fragment
     */
    private void goSettings() {
        DrawerLayout drawer = findViewById(id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        TextView localTextView = findViewById(R.id.textView2);
        localTextView.setText("Einstellungen");
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        SettingsFragment calendar = new SettingsFragment();
        transaction.replace(id.sample_content_fragment, calendar, "settings");
        transaction.addToBackStack("settings");
        transaction.commit();
    }
}