package com.example.d070700.demoapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * This fragment contains the appointments to be scheduled.
 * The workflow is similar to the main RecyclerViewFragment
 */
public class UnscheduledFragment extends Fragment {

    protected RecyclerView mRecyclerView;
    protected UnscheduledAdapter mAdapter;
    protected RecyclerView.LayoutManager mLayoutManager;
    private List<CustomerAppointment> customers;
    private JsonArray query = new JsonArray();
    private CustomerAppointment customerAppointment;

    /**
     * Basic create method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param savedInstanceState - Bundle from class View
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // DB connection to fetch data
        try {
            if (checkConnection()) {
                new ConnectServerTask().execute().get(5, TimeUnit.SECONDS);
            } else {
                //handle if no internet connection exists
                Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "No internet connection", Snackbar.LENGTH_SHORT);
                snackbar.show();
            }
        } catch (TimeoutException e) {
            //handle if the connection timed out
            Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "Server timeout", Snackbar.LENGTH_SHORT);
            snackbar.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Basic View Creation method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param inflater           - LayoutInflater from calling class
     * @param container          - ViewGroup from class View
     * @param savedInstanceState - Bundle from class View
     * @return - the created View
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recycler_view_fragment, container, false);
        rootView.setTag("UnscheduledFragment");
        mRecyclerView = rootView.findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager((getActivity()));

        //create adapter and content for data
        ArrayList<JsonObject> list = new ArrayList<>();
        for (JsonElement obj : query) {
            list.add((JsonObject) obj);
        }
        createDataset(list);
        mAdapter = new UnscheduledAdapter(customers, this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(mLayoutManager);
        return rootView;
    }

    /**
     * Checks if an active internet connection exists, returns true if so
     *
     * @return - boolean
     */
    private boolean checkConnection() {
        ConnectivityManager cm =
                (ConnectivityManager) Objects.requireNonNull(getContext()).getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = Objects.requireNonNull(cm).getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    /**
     * creates a dataset based on the data fetched from the server
     *
     * @param list - List of JsonObjects to be stored in localJsonArray objects for the adapter
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createDataset(ArrayList<JsonObject> list) {
        customers = new ArrayList<>();

        for (int i = 0; i < list.size(); i++) {
            JsonObject local = list.get(i);
            customers.add(new CustomerAppointment(
                    local.get("lastName").toString(),
                    local.get("address").toString(),
                    local.get("addition").toString(),
                    local.get("zip").toString(),
                    local.get("city").toString(),
                    local.get("phone").toString(),
                    local.get("notes").toString(),
                    local.get("email").toString(),
                    local.get("mobile").toString(),
                    local.get("phoneBusi").toString(),
                    local.get("emailBusi").toString(),
                    local.get("start").toString(),
                    local.get("id").toString()));
        }
    }

    /**
     * Called if an appointment should be scheduled
     *
     * @param customerAppointment - the appointment to be scheduled
     */
    public void change(CustomerAppointment customerAppointment) {
        this.customerAppointment = customerAppointment;
        AlertDialog.Builder builder;
        // version check
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()), android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        }
        builder.setTitle("Schedule Appointment")
                .setMessage("Do you want to schedule this appointment automatically?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {

                    try {
                        if (checkConnection()) {
                            dialog.dismiss();
                            new ScheduleAppointmentTask().execute().get(5, TimeUnit.SECONDS);
                        } else {
                            Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "No internet connection", Snackbar.LENGTH_SHORT);
                            snackbar.show();
                        }
                    } catch (TimeoutException e) {
                        Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "Server connection lost", Snackbar.LENGTH_SHORT);
                        snackbar.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                })
                .setNegativeButton(android.R.string.no, (dialog, which) -> {
                    // do nothing
                })
                .setIcon(android.R.drawable.ic_dialog_info)
                .show();
    }

    /**
     * Creates an asynchronous task to schedule an appointment
     * The error handling has to be implemented in the method creating an instance of this class
     */
    @SuppressLint("StaticFieldLeak")
    private class ScheduleAppointmentTask extends AsyncTask<Void, Integer, Void> {
        @Override
        protected Void doInBackground(Void... appoint) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String id = customerAppointment.getId();
                toServer.writeObject("schedule");
                String dummy = (String) fromServer.readObject();
                if (dummy.equals("Connection established")) {
                    toServer.writeObject(id);
                    String transfer = (String) fromServer.readObject();
                    Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getView()), transfer, Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
                socketToServer.close();
            } catch (Exception e) {
                System.err.println(e);
            }
            return null;
        }
    }

    @Override
    public void onResume(){
        TextView headline = Objects.requireNonNull(getActivity()).findViewById(R.id.textView2);
        headline.setText("Termine verwalten");
        super.onResume();
    }

    /**
     * Creates an asynchronous task to fetch data from the server
     * The error handling has to be implemented in the method creating an instance of this class
     */
    @SuppressLint("StaticFieldLeak")
    private class ConnectServerTask extends AsyncTask<Void, Integer, Void> {

        JsonArray local = new JsonArray();

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String dummy = (String) fromServer.readObject();
                if (dummy.equals("Connection established")) {
                    String input = "undated";
                    toServer.writeObject(input);
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    local = gson.fromJson(transfer, JsonArray.class);
                    JsonObject obj = (JsonObject) local.get(0);
                    query = local;
                }
                socketToServer.close();
            } catch (IOException e) {
                System.err.println(e);
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                System.err.println(e);
            } catch (ClassNotFoundException e) {
                System.err.println(e);
            }
            return null;
        }
    }
}