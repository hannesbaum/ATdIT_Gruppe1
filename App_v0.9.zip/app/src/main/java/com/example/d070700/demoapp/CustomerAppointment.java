package com.example.d070700.demoapp;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * This class is used to handle the received Data from the database in an easier way.
 * An object of this class simulates a database-join of appointment and customer
 * Because the returned Data is in Json format and the access is limited, because some string need further
 * formatting, this class provides an access throughout the app so errors and possible conversion mistakes
 * are minimalized
 * <p>
 * This class mostly consists of getter and setter method while making sure the values are of the necessary datatypes
 * to use them further on in the app
 */

public class CustomerAppointment {

    private String name;
    private String address;
    private String addition;
    private String zip;
    private String city;
    private String phone;
    private String notes;
    private String email;
    private String mobile;
    private String phoneBusiness;
    private String emailBusiness;
    private String id;
    private LocalTime lt;

    /**
     * The constructor for the class
     *
     * @param name          - Customer name
     * @param address       - Customer address
     * @param addition      - Customer address addition
     * @param zip           - Customer zip code
     * @param city          - Customer city
     * @param phone         - Customer phone
     * @param notes         - Notes created by the Customer
     * @param email         - Customer email
     * @param mobile        - Customer cellphone
     * @param phoneBusiness - Customer business Phone
     * @param emailBusiness - Customer business cell
     * @param time          - Start time of appointment
     * @param id            - appointment id
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    CustomerAppointment(String name, String address, String addition, String zip, String city, String phone,
                        String notes, String email, String mobile, String phoneBusiness, String emailBusiness, String time, String id) {
        this.name = usefulString(name);
        this.addition = usefulString(addition);
        this.address = usefulString(address);
        this.zip = usefulString(zip);
        this.phone = usefulString(phone);
        this.city = usefulString(city);
        this.notes = usefulString(notes);

        if (!time.equals("''")) {
            usefulString(time);
            if (time.length() == 7)     // unformatted time String has following format: "hh:mm" (including apostrophes)
                lt = LocalTime.parse(usefulString(time), DateTimeFormatter.ofPattern("HH:mm"));
        }
        this.mobile = usefulString(mobile);
        this.email = usefulString(email);
        this.emailBusiness = usefulString(emailBusiness);
        this.phoneBusiness = usefulString(phoneBusiness);
        this.id = id;
    }

    /**
     * Returns current appointment id
     * @return - String
     */
    public String getId() {
        return this.id;
    }

    /**
     * Sets the name of the customer
     * @param name - Customer's name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the customer's name
     * @return - String
     */
    public String getName() {
        return this.name;
    }

    /**
     * Returns the customer#s address
     * @return - String
     */
    public String getAddress() {
        return this.address;
    }

    /**
     * Returns the customer's address addition
     * @return - String
     */
    public String getAddition() {
        return this.addition;
    }

    /**
     * Returns the customer's zip code
     * @return - String
     */
    public String getZip() {
        return zip;
    }

    /**
     * Returns the customer's city
     * @return - String
     */
    public String getCity() {
        return this.city;
    }

    /**
     * Sets the customer's phone number
     * @param phone - String
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Returns the customer's phone number
     * @return - String
     */
    public String getPhone() {
        return this.phone;
    }

    /**
     * Returns the customer's notes
     * @return - String
     */
    public String getNotes() {
        return this.notes;
    }

    /**
     * Returns the customer's cell number
     * @return - String
     */
    public String getMobile() {
        return this.mobile;
    }

    /**
     * Returns the customer's email
     * @return - String
     */
    public String getEmail() {
        return this.email;
    }

    /**
     *Returns the customer's business phone number
     * @return - String
     */
    public String getPhoneBusiness() {
        return this.phoneBusiness;
    }

    /**
     * Returns the customer's business email
     * @return - String
     */
    public String getEmailBusiness() {
        return this.emailBusiness;
    }

    /**
     * Returns the start time as a string
     * @return - String
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getTime() {
        if (lt != null) {
            String getMin = "0";
            String getHo = "0";
            if (lt.getHour() < 10)
                getHo += lt.getHour();
            else
                getHo = "" + lt.getHour();
            if (lt.getMinute() < 10)
                getMin += lt.getMinute();
            else
                getMin = "" + lt.getMinute();
            return getHo + ":" + getMin;
        } else
            return null;
    }


    /**
     * Formats a string with extra apostrophes for further usage
     * @param str  -The string to be formatted
     * @return - String
     */
    private String usefulString(String str) throws IndexOutOfBoundsException{
        try {
            StringBuilder builder = new StringBuilder(str);
            if (builder.charAt(0) == '\"')
                builder.deleteCharAt(0);
            if (builder.charAt(builder.length() - 1) == '\"')
                builder.deleteCharAt(builder.length() - 1);
            return builder.toString();
        }
        catch(IndexOutOfBoundsException e){
            throw new IndexOutOfBoundsException();
        }
    }
}
