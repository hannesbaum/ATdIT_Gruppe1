package com.example.d070700.demoapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.Objects;

public class ContactFragment extends Fragment {
    private CustomerAppointment customerAppointment;

    /**
     * Creates the Contact Fragment
     * This method is called by the app itself and therefore does not have to be called specifically
     * @param savedInstanceState - Bundle from the View class
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /**
     * Creates the view Contact Fragment
     * This method is called by the app itself and therefore does not have to be called specifically
     * @param inflater - LayoutInflater from the superclass
     * @param container - ViewGroup from View class
     * @param savedInstanceState - Bundle from View class
     * @return - returns the created View
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.contact, container, false);
        rootView.setTag("ContactFragment");
        TextView phone = rootView.findViewById(R.id.phoneDisplay),
                phoneMobile = rootView.findViewById(R.id.phoneDisplay2),
                phoneBusi = rootView.findViewById(R.id.phoneDisplayBusi),
                email = rootView.findViewById(R.id.emailDisplay),
                emailBusi = rootView.findViewById(R.id.emailDisplayBusi);
        if (customerAppointment != null) {
            phone.setText(customerAppointment.getPhone());
            phoneMobile.setText(customerAppointment.getMobile());
            phoneBusi.setText(customerAppointment.getPhoneBusiness());
            email.setText(customerAppointment.getEmail());
            emailBusi.setText(customerAppointment.getEmailBusiness());
        }
        phone.setOnClickListener((v) -> {
                    String call = customerAppointment.getPhone();
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + call));
                    startActivity(intent);
                }
        );

        phoneMobile.setOnClickListener((v) -> {
                    String call = customerAppointment.getPhone();
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + call));
                    startActivity(intent);
                }
        );

        phoneBusi.setOnClickListener((v) -> {
                    String call = customerAppointment.getPhone();
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + call));
                    startActivity(intent);
                }
        );

        final Button cancel = rootView.findViewById(R.id.cancelDate);
        cancel.setOnClickListener((v) -> {
            String number = customerAppointment.getPhone();
            String name = customerAppointment.getName();
            Intent sms = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", number, null));
            sms.putExtra("sms_body", "Sehr geehrter Herr/Frau " + name +
                    "\nLeider müssen wir Ihren heutigen Termin" +
                    " kurzfristig absagen. Wir bitten um Entschuldigung. \nIhr MK Ablesedienst");
            startActivity(sms);
        });

        final Button push = rootView.findViewById(R.id.pushDate);
        push.setOnClickListener((v) -> {
            String number = customerAppointment.getPhone();
            String name = customerAppointment.getName();
            Intent sms = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", number, null));
            sms.putExtra("sms_body", "Sehr geehrter Herr/Frau " + name +
                    "\nLeider müssen wir Ihren heutigen Termin" +
                    " kurzfristig verschieben. Ein Mitarbeiter wird sich umgehend mit einem neuen" +
                    " Terminvorschlag bei Ihnen melden. Wir bitten um Entschuldigung. \nIhr MK Ablesedienst");
            startActivity(sms);
        });

        final Button later = rootView.findViewById(R.id.laterArrival);
        later.setOnClickListener((v) -> {
            String number = customerAppointment.getPhone();
            String name = customerAppointment.getName();
            Intent sms = new Intent(Intent.ACTION_VIEW, Uri.fromParts("sms", number, null));
            sms.putExtra("sms_body", "Sehr geehrter Herr/Frau " + name +
                    "\nWir informieren Sie hiermit, dass unser/e Mitarbeiter/in heute mit" +
                    " einiger Verzögerung bei Ihnen eintreffen werden." +
                    " Wir bitten um Entschuldigung. \nIhr MK Ablesedienst");
            startActivity(sms);
        });

        return rootView;
    }


    @Override
    public void onResume(){
        TextView headline = Objects.requireNonNull(getActivity()).findViewById(R.id.textView2);
        headline.setText(customerAppointment.getName());
        super.onResume();
    }

    /**
     * With this method one can set the localJsonArray CustomerAppointment Object
     * By setting the right object, on assures that the displayed data is correct
     * @param customerAppointment - a CustomerAppointment object whose data shall be displayed
     */
    public void setCustomerAppointment(CustomerAppointment customerAppointment) {
        this.customerAppointment = customerAppointment;
    }
}