package com.example.d070700.demoapp;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * This fragment contains the settings page for the app
 * In this demo version, no further implementations are made at this point
 */
public class SettingsFragment extends Fragment {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    /**
     * Creates a new fragment which contains the settings of the app
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.settings, container, false);
        rootView.setTag("SettingsFragment");
        return rootView;
    }

}