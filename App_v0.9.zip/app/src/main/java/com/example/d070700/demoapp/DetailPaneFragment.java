package com.example.d070700.demoapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * This class creates the Deail Pane Fragment which shows more detailed information about a customerAppointment and
 * the corresponding appointment and lets the user take action based on the task to complete.
 */
public class DetailPaneFragment extends Fragment {

    private CustomerAppointment customerAppointment;
    private int deviceCount = 0;
    private TextView headline;

    /**
     * Basic creation method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param savedInstanceState - Bundle from class View
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ConnectivityManager cm =
                (ConnectivityManager) Objects.requireNonNull(getContext()).getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = Objects.requireNonNull(cm).getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        try {
            if (isConnected) {
                new ConnectDBTask().execute().get(5, TimeUnit.SECONDS);
            } else {
                // handling if no internet connection is available
                Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "No internet connection", Snackbar.LENGTH_SHORT);
                snackbar.show();
            }
        } catch (TimeoutException e) {
            //handling if the connection times out
            Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "Server connection lost", Snackbar.LENGTH_SHORT);
            snackbar.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Basic view creation method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param inflater           - Layout Inflater from calling class
     * @param container          - ViewGroup from class View
     * @param savedInstanceState - Bundle from class View
     * @return - the created View
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.detail_pane2, container, false);
        rootView.setTag("DetailPaneFragment");
        headline = Objects.requireNonNull(getActivity()).findViewById(R.id.textView2);
        TextView address = rootView.findViewById(R.id.AdressText),
                addition = rootView.findViewById(R.id.AdressAdditionText),
                zip = rootView.findViewById(R.id.ZipText),
                city = rootView.findViewById(R.id.CityText),
                phone = rootView.findViewById(R.id.PhoneText),
                notes = rootView.findViewById(R.id.NotesText);

        if (customerAppointment != null) {
            address.setText(customerAppointment.getAddress());
            addition.setText(customerAppointment.getAddition());
            zip.setText(customerAppointment.getZip());
            city.setText(customerAppointment.getCity());
            phone.setText(customerAppointment.getPhone());
            notes.setText(customerAppointment.getNotes());
            headline.setText(customerAppointment.getName());
        }

        //Listener for "Contact"-Button
        final Button contact = rootView.findViewById(R.id.ContactButton);
        contact.setOnClickListener(v -> {
            if (customerAppointment != null)
                ((MainActivity) getActivity()).transferButtons("contact", customerAppointment);
        });

        //Listener for "Ablesen"-Button
        final Button setData = rootView.findViewById(R.id.SetValuesButton);
        setData.setOnClickListener(v -> {
            if (customerAppointment != null && deviceCount != 0) {
                ((MainActivity) getActivity()).setDataTransfer(deviceCount);
            }
        });

        //Listener for "Werte bearbeiten"-Button
        final Button editData = rootView.findViewById(R.id.EditValuesButton);
        editData.setOnClickListener(v -> {
        });
        return rootView;
    }

    /**
     * Refreshes the fragments-specified data
     */
    @Override
    public void onResume() {
        if (customerAppointment != null)
            headline.setText(customerAppointment.getName());
        super.onResume();
    }

    /**
     * Set a customerAppointment object to display the right data
     *
     * @param customerAppointment - object whose data shall be displayed
     */
    public void setCustomerAppointment(CustomerAppointment customerAppointment) {
        this.customerAppointment = customerAppointment;
    }

    /**
     * Formats a string with additional apostrophes
     *
     * @param str - The String to be formatted
     * @return - String
     */
    private String formatString(String str) {
        StringBuilder builder = new StringBuilder(str);
        if (builder.charAt(0) == '\"')
            builder.deleteCharAt(0);
        if (builder.charAt(builder.length() - 1) == '\"')
            builder.deleteCharAt(builder.length() - 1);
        return builder.toString();
    }

    /**
     * The Server connection handled by an asynchronous thread
     * The error handling has to be implemented in the method which creates an instance of this class
     */
    @SuppressLint("StaticFieldLeak")
    private class ConnectDBTask extends AsyncTask<Void, Integer, Void> {
        JsonArray localJsonArray = new JsonArray();

        @Override
        protected Void doInBackground(Void... var) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String dummy = (String) fromServer.readObject();
                if (dummy.equals("Connection established")) {
                    toServer.writeObject("getCounters");
                    toServer.writeObject(customerAppointment.getId());
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    localJsonArray = gson.fromJson(transfer, JsonArray.class);
                    JsonObject obj = (JsonObject) localJsonArray.get(0);
                    String count = formatString(obj.get("counterNr").toString());
                    deviceCount = Integer.parseInt(count);
                }
                socketToServer.close();
            } catch (IOException e) {
                System.err.println(e);
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                System.err.println(e);
            } catch (ClassNotFoundException e) {
                System.err.println(e);
            }
            return null;
        }
    }
}
