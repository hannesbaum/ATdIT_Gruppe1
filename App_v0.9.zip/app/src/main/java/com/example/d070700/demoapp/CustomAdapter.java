package com.example.d070700.demoapp;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * This Adapter class handles the content of the main Recycler View Fragment
 */

class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

    /**
     * Inner ViewHolder class which is used to store the data in a ViewHolder
     */
    static class ViewHolder extends RecyclerView.ViewHolder {

        CardView cv;
        private TextView personName, personAddress, personTime;
        private CustomerAppointment currentItem;
        private View view;

        ViewHolder(View itemView) {
            super(itemView);
            view = itemView;
            cv = itemView.findViewById(R.id.cv);
            personName = itemView.findViewById(R.id.customer_name);
            personAddress = itemView.findViewById(R.id.customer_address);
            personTime = itemView.findViewById(R.id.customer_time);
        }
    }

    private List<CustomerAppointment> customerAppointments;
    private RecyclerViewFragment source;

    /**
     * Constructor for the Adapter
     * This constructor is called by the RecyclerViewFragment
     * @param customerAppointments - List of customerAppointment objects which shall be displayed
     * @param source - the calling recyclerViewFragment
     */
    CustomAdapter(List<CustomerAppointment> customerAppointments, RecyclerViewFragment source) {
        this.customerAppointments = customerAppointments;
        this.source = source;
    }

    /**
     * Creates the ViewHolder for the content
     * Similar to the OnCreateView Method
     * @param viewGroup - ViewGroup of the caller object
     * @param viewType - viewType of the caller Object
     * @return viewHolder - the ViewHolder which holds the layout for the content display
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        // Create a new view.
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item, viewGroup, false);
        return new ViewHolder(v);
    }

    /**
     * Displays the individual customer data and sets onClickListeners
     * @param holder - ViewHolder of caller object
     * @param i - i - index position for the list customerAppointments
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int i) {
        holder.personName.setText(customerAppointments.get(i).getName());
        holder.personAddress.setText(customerAppointments.get(i).getAddress());
        holder.personTime.setText(customerAppointments.get(i).getTime());
        holder.currentItem = customerAppointments.get(i);
        holder.view.setOnClickListener(v -> source.change(holder.currentItem));
    }

    /**
     * @return - returns the size of the list with customerAppointments
     */
    @Override
    public int getItemCount() {
        return customerAppointments.size();
    }
}
