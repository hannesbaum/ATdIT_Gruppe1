package com.example.d070700.demoapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * The Data Input Fragment is created if the values of the devices should be inserted and saved in the database
 * Depending on the count of the devices in an apartment, the corresponding amount of fragments are created by pressing "Continue"
 */
public class DataInputFragment extends Fragment {
    private static int deviceCount = 0;     //the amount of devices in the corresponding aparment
    private static int currentDevice = 0;   //the current device count (always <= deviceCount)
    private static JsonArray inputData = new JsonArray();   //the amount of data which was inserted

    /**
     * Standard creation method for Fragment
     * This method is called by the app itself and therefore does not have to be called specifically
     * @param savedInstanceState - Bundle from class
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        currentDevice++;
    }

    /**
     * This method sets the amount of devices per apartment, so the right amount of fragments is created
     *
     * @param count - int: amount of devices in the apartment
     */
    public void setDeviceCount(int count) {
        deviceCount = count;
    }

    /**
     * resets the count of the devices and deletes the stored data
     */
    public void resetCount() {
        currentDevice = 0;
        inputData = new JsonArray();
    }

    /**
     * Standard onCreateView method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param inflater           - LayoutInflater from calling class
     * @param container          - ViewGroup from class View
     * @param savedInstanceState - Bundle from class View
     * @return - View
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.set_values, container, false);
        rootView.setTag("set_values_view");
        //Objects.requireNonNull is a method which safe handles that the parameter exists
        TextView headline = Objects.requireNonNull(getActivity()).findViewById(R.id.textView2);
        headline.setText("Zähler " + currentDevice);
        final Button cancelButton = rootView.findViewById(R.id.cancelButton);
        //if too many subfragments have been created, the useless fragments will be deleted from the backstack
        cancelButton.setOnClickListener(v -> {
            for (int i = getActivity().getSupportFragmentManager().getBackStackEntryCount(); i > 2; i--) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
            getActivity().onBackPressed();
        });
        final Button continueButton = rootView.findViewById(R.id.continueButton);
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        String transferString = "setData" + (currentDevice + 1);
        if (currentDevice == deviceCount) {
            continueButton.setText("Abschicken");
            continueButton.setOnClickListener((v) -> {
                        try {
                            saveData();
                            if (checkConnection()) {
                                new ConnectServerTask().execute().get(5, TimeUnit.SECONDS);
                            } else {
                                RecyclerViewFragment fragment = (RecyclerViewFragment) getActivity().getSupportFragmentManager().findFragmentByTag("RecyclerViewFragment1");
                                fragment.setEmergencySaveInputData(inputData);
                                Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "No internet connection: Data saved", Snackbar.LENGTH_SHORT);
                                snackbar.show();
                            }
                        } catch (TimeoutException e) {
                            RecyclerViewFragment fragment = (RecyclerViewFragment) getActivity().getSupportFragmentManager().findFragmentByTag("RecyclerViewFragment1");
                            fragment.setEmergencySaveInputData(inputData);
                            Snackbar snackbar = Snackbar.make(getActivity().findViewById(android.R.id.content), "Server timeout: Data saved", Snackbar.LENGTH_SHORT);
                            snackbar.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        ((MainActivity) getActivity()).goHome(null);
                    }
            );
        } else {
            continueButton.setOnClickListener((v) -> {
                        saveData();
                        DataInputFragment inputFragment = new DataInputFragment();
                        transaction.replace(R.id.sample_content_fragment, inputFragment, transferString);
                        transaction.addToBackStack("setData1");
                        transaction.commit();
                    }
            );
        }
        return rootView;
    }

    /**
     * Saves the entered data into the static JsonArray
     */
    private void saveData() {
        TextInputEditText currentUsageField = Objects.requireNonNull(getActivity()).findViewById(R.id.currentUsage),
                deviceTestField = getActivity().findViewById(R.id.deviceTest),
                deadlineDateField = getActivity().findViewById(R.id.deadlineDate),
                deadlineUsageField = getActivity().findViewById(R.id.deadlineUsage),
                checkSumField = getActivity().findViewById(R.id.checkSum);

        JsonObject dataEntry = new JsonObject();
        dataEntry.addProperty("countNow", currentUsageField.getText().toString());
        dataEntry.addProperty("deviceTest", deviceTestField.getText().toString());
        dataEntry.addProperty("dueDate", deadlineDateField.getText().toString());
        dataEntry.addProperty("countDueDate", deadlineUsageField.getText().toString());
        dataEntry.addProperty("checkSum", checkSumField.getText().toString());

        inputData.add(dataEntry);
    }

    /**
     * Checks if a network connection is available and returns true if so
     *
     * @return - boolean
     */
    private boolean checkConnection() {
        ConnectivityManager cm =
                (ConnectivityManager) Objects.requireNonNull(getContext()).getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = Objects.requireNonNull(cm).getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    /**
     * This task connects to the Server
     * Because network activities are often leading to errors or timeouts, they are not supposed to be executed in the main thread
     * This class creates an asynchronous task which will establish a connection to the server (if possible)
     * The error handling is managed in the OnCreateView method, where an instance of this class is used
     */
    @SuppressLint("StaticFieldLeak")
    private class ConnectServerTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... var) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String dummy = (String) fromServer.readObject();    //this will receive the "Connection established" String
                if (dummy.equals("Connection established")) {
                    toServer.writeObject("updateData");
                    Gson gson = new Gson();
                    String transferToServer = gson.toJson(inputData);
                    toServer.writeObject(transferToServer);
                }
                socketToServer.close();
            } catch (IOException e) {
                System.err.println(e);
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                System.err.println(e);
            } catch (ClassNotFoundException e) {
                System.err.println(e);
            }
            return null;
        }
    }
}