package com.example.d070700.demoapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * This class creates a Fragment which will contain the main data on the front page
 * This fragment is called by the MainActivity at the creation of the app
 */
public class RecyclerViewFragment extends Fragment {

    protected RecyclerView mRecyclerView;
    protected CustomAdapter mAdapter;
    protected RecyclerView.LayoutManager mLayoutManager;
    private List<CustomerAppointment> customerAppointments;
    private JsonArray query = new JsonArray();
    private JsonArray emergencySaveInputData = new JsonArray();

    /**
     * Standard create method for the fragment
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param savedInstanceState - Bundle from class View
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        try {
            if (checkConnection()) {
                new ConnectServerTask().execute().get(5, TimeUnit.SECONDS);
            } else {
                //handle if no internet connection is available
                Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "No internet connection", Snackbar.LENGTH_SHORT);
                snackbar.show();
            }
        } catch (TimeoutException e) {
            //handle if the connection to the server is invalid
            Snackbar snackbar = Snackbar.make(Objects.requireNonNull(getActivity()).findViewById(android.R.id.content), "Server timeout", Snackbar.LENGTH_SHORT);
            snackbar.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Standard View Creation method
     * This method is called by the app itself and therefore does not have to be called specifically
     *
     * @param inflater           - LayoutInflater from calling class
     * @param container          - ViewGroup from class View
     * @param savedInstanceState - Bundle from class View
     * @return - View - the created View
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recycler_view_fragment, container, false);
        rootView.setTag("RecyclerViewFragment1");
        mRecyclerView = rootView.findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager((getActivity()));
        ArrayList<JsonObject> list = new ArrayList<>();
        for (JsonElement obj : query) {
            list.add((JsonObject) obj);
        }
        createDataset(list);
        mAdapter = new CustomAdapter(customerAppointments, this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(mLayoutManager);
        return rootView;
    }

    /**
     * Creates a dataset from the received Json Data from the server and stores the data in
     * localJsonArray CustomerAppointment objects
     * The final storage object is a list
     *
     * @param list - List containing the JsonObjects from the server
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createDataset(ArrayList<JsonObject> list) {
        customerAppointments = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            JsonObject localJsonObject = list.get(i);
            customerAppointments.add(new CustomerAppointment(
                    localJsonObject.get("lastName").toString(),
                    localJsonObject.get("address").toString(),
                    localJsonObject.get("addition").toString(),
                    localJsonObject.get("zip").toString(),
                    localJsonObject.get("city").toString(),
                    localJsonObject.get("phone").toString(),
                    localJsonObject.get("notes").toString(),
                    localJsonObject.get("email").toString(),
                    localJsonObject.get("mobile").toString(),
                    localJsonObject.get("phoneBusi").toString(),
                    localJsonObject.get("emailBusi").toString(),
                    localJsonObject.get("start").toString(),
                    localJsonObject.get("id").toString()));
        }
    }

    public void change(CustomerAppointment customer) {
        ((MainActivity) Objects.requireNonNull(getActivity())).transferButtons("detail", customer);
    }

    /**
     * Called, when the app is resumed
     * This method checks if data has to be sent to the server and does so if the connection is valid
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onResume() {
        refreshHeadline();
        if (checkConnection()) {
            try {
                Object validContent = emergencySaveInputData.get(0);
                if (validContent != null)
                    new SendDataTask().execute().get(5, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            }
        }
        super.onResume();
    }

    /**
     * Checks if an internet connection is available and returns true if so
     *
     * @return - boolean
     */
    private boolean checkConnection() {
        ConnectivityManager cm =
                (ConnectivityManager) Objects.requireNonNull(getContext()).getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = Objects.requireNonNull(cm).getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    /**
     * Refreshs the Headline with the current date based on the System time
     * Requires API is necessary because LocalDateTime, etc. are only supported since Java 8
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void refreshHeadline() {
        TextView date = Objects.requireNonNull(getActivity()).findViewById(R.id.textView2);       // "headline" textview which is part of the main activity
        LocalDateTime local = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd.MM.");  // date format: Weekday, Day, Month
        date.setText(local.format(formatter));
    }

    /**
     * Provides a possibility to save data in the start page fragment if no internet connection is established and
     * the data would otherwise be lost.
     * From this fragment, the app will try to resend the data everytime it is refreshed
     *
     * @param arr - the JsonArray with the data to be saved
     */
    public void setEmergencySaveInputData(JsonArray arr) {
        emergencySaveInputData = arr;
        System.out.println(emergencySaveInputData);
    }

    /**
     * This class creates an asynchronous task trying to send data to the server
     * The error handling has to be implemented in the method creating an instance of this class
     */
    @SuppressLint("StaticFieldLeak")
    private class SendDataTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... var) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String dummy = (String) fromServer.readObject();    //this will receive the "Connection established" String
                if (dummy.equals("Connection established")) {
                    toServer.writeObject("updateData");
                    Gson gson = new Gson();
                    String transferToServer = gson.toJson(emergencySaveInputData);
                    System.out.println(transferToServer);
                    toServer.writeObject(transferToServer);
                }
                socketToServer.close();
            } catch (IOException e) {
                System.err.println(e);
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                System.err.println(e);
            } catch (ClassNotFoundException e) {
                System.err.println(e);
            }
            return null;
        }
    }

    /**
     * This class creates an asynchronous task trying to fetch data from the server
     * The error handling has to be implemented in the method creating an instance of this class
     */
    @SuppressLint("StaticFieldLeak")
    private class ConnectServerTask extends AsyncTask<Void, Integer, Void> {
        JsonArray localJsonArray = new JsonArray();

        @Override
        protected Void doInBackground(Void... var) {
            try {
                Socket socketToServer = new Socket("10.0.2.2", 200);
                ObjectOutputStream toServer = new ObjectOutputStream(socketToServer.getOutputStream());
                ObjectInputStream fromServer = new ObjectInputStream(socketToServer.getInputStream());
                String dummy;
                dummy = (String) fromServer.readObject();
                if (dummy.equals("Connection established")) {
                    toServer.writeObject("query");
                    String transfer;
                    Gson gson = new Gson();
                    transfer = (String) fromServer.readObject();
                    localJsonArray = gson.fromJson(transfer, JsonArray.class);
                    query = localJsonArray;
                }
                socketToServer.close();
            } catch (IOException e) {
                System.err.println(e);
            } catch (RuntimeException e) {        //catches Security and IAE exceptions
                System.err.println(e);
            } catch (ClassNotFoundException e) {
                System.err.println(e);
            }
            return null;
        }
    }
}

