package com.example.d070700.demoapp;

import junit.framework.Assert;

import org.junit.Test;

import static org.junit.Assert.*;

public class CustomerAppointmentConstructorUnitTest {


    CustomerAppointment localObject;

    @Test
    public void constructorTest() {
        localObject = new CustomerAppointment("a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a");
        assertNotNull(localObject);
    }
}
