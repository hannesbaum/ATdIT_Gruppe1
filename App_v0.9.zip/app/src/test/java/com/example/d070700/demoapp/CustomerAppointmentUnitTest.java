package com.example.d070700.demoapp;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class CustomerAppointmentUnitTest {

    CustomerAppointment localObject;

    @Before
    public void init() {
        localObject = new CustomerAppointment("name", "address", "addition", "zip", "city", "phone", "notes", "email", "mobile", "phoneB", "emailB", "time", "id");
    }

    @Test
    public void testGetId(){
        assertEquals(localObject.getId(), "id");
    }

    @Test
    public void testGetName(){
        assertEquals(localObject.getName(), "name");
    }

    @Test
    public void testSetName(){
        localObject.setName("b");
        assertEquals(localObject.getName(), "b");
    }

    @Test
    public void testGetAddress(){
        assertEquals(localObject.getAddress(), "address");
    }

    @Test
    public void testGetAddition(){
        assertEquals(localObject.getAddition(), "addition");
    }

    @Test
    public void testGetZip(){
        assertEquals(localObject.getZip(), "zip");
    }

    @Test
    public void testGetCity(){
        assertEquals(localObject.getCity(), "city");
    }

    @Test
    public void testGetPhone(){
        assertEquals(localObject.getPhone(), "phone");
    }

    @Test
    public void testSetPhone(){
        localObject.setPhone("1234");
        assertEquals(localObject.getPhone(), "1234");
    }

    @Test
    public void testGetNotes(){
        assertEquals(localObject.getNotes(), "notes");
    }

    @Test
    public void testGetMobile(){
        assertEquals(localObject.getMobile(), "mobile");
    }

    @Test
    public void testGetEmail(){
        assertEquals(localObject.getEmail(), "email");
    }

    @Test
    public void testGetEmailBusiness(){
        assertEquals(localObject.getEmailBusiness(), "emailB");
    }

    @Test
    public void testGetPhoneBusiness(){
        assertEquals(localObject.getPhoneBusiness(), "phoneB");
    }

    @Test
    public void testGetTime(){
        assertNull(localObject.getTime());
    }
}