package Projekt_Server;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;


public class CreateDB {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			Class.forName("org.sqlite.JDBC");

			Connection connection = DriverManager.getConnection("jdbc:sqlite:first.db");

			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30); // set timeout to 30 sec.

			statement.executeUpdate("DROP TABLE IF EXISTS customer");
			statement.executeUpdate(
					"CREATE TABLE customer (name TEXT, address TEXT, addition TEXT, zip TEXT, city TEXT, phone TEXT,"
							+ "notes TEXT, email TEXT, mobile TEXT, phoneBusi TEXT, emailBusi TEXT, time TEXT, id TEXT)");

			statement.executeUpdate(
					"INSERT INTO customer values" + "('Peter', 'Stra�e 1', 'none', '68617', 'Mannheim', '1234',"
							+ " 'keine notes', 'email1', '2345', 'busiPhone', 'busiE', '2018-05-30 13:00', '1')");

			// statement.executeUpdate("UPDATE person SET name='Peter' WHERE id='1'");
			// statement.executeUpdate("DELETE FROM person WHERE id='1'");

			// resultSet = statement.executeQuery("SELECT * from customer");
			// while (resultSet.next()) {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
