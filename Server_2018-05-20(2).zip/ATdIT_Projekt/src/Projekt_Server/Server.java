package Projekt_Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.time.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

//import javax.json.*;
import com.google.gson.*;
import com.google.gson.GsonBuilder;

/**
 * The class server provides a server socket for comunication with other clients
 * via the local network In the standard configuration the port 200 is used.
 * Remember if the port is changed, the clients have to change their connection
 * port as well, otherwise no connection is established.
 * 
 * The server will start a protocol (AuskunftProtocol) which determines the
 * communication between client and server. This process will run infinitely and
 * can only be stopped by a fatal Java error or by manual termination.
 * 
 * @author D070700
 *
 */
class Server {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			ServerSocket server = new ServerSocket(200);
			System.out.println("Server gestartet");
			while (true) {
				Socket s = server.accept();
				new AuskunftProtocol(s).start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (RuntimeException e) { // catches Security and IAE Exceptions
			e.printStackTrace();
		}
	}
}

/**
 * The class AuskunftProtocol provides a protocol according to which the server
 * and client communicate with each other In here, different communications are
 * analyzed and corresponding actions are taken like DB-queries and DB-updates
 * This class might throw different exeptions such as IOExceptions,
 * SQLExceptions and other RuntimeExceptions as IAEs
 * 
 * To transfer data via the network, serialization is used. In this scenario,
 * the data can be only an instance of an object that both classes know.
 * Therefore, one cannot transfer custom datatypes, because they are not
 * explictly known to both sides. To solve this problem, the database results
 * are transfered into JSON Objects and stored in a JSON array. This array
 * (represented by "com.google.gson.JsonArray") is transfered to the client and
 * will be "decoded" back into a usable object.
 * 
 * @author D070700
 *
 */
class AuskunftProtocol extends Thread {
	Socket s; // Socket from the client
	BufferedReader fromClient; // inputStream from Client
	ObjectOutputStream toClient; // OutputStream to Client
	int nr = 0;
	static int anzahl = 0;
	private ResultSet resultSet; // resultSet for DB queries
	JsonObject value = new JsonObject();
	JsonArray array = new JsonArray();
	String input = "", transfer = "";
	Connection connection = null; // connection to database
	Statement statement = null; // object needed to execute SQL orders
	Gson gson = new Gson(); // object used for data serialization

	/**
	 * Basic constructor for the AuskunftProtocol which takes a socket as a
	 * parameter
	 * 
	 * @param s
	 *            - Socket s which establishes the connection between Server/client
	 * @throws ClassNotFoundException
	 *             - is thrown if required sqlite references are not found
	 */
	public AuskunftProtocol(Socket s) throws ClassNotFoundException {
		try {
			this.s = s;
			nr = ++anzahl;
			fromClient = new BufferedReader(new InputStreamReader(s.getInputStream()));
			toClient = new ObjectOutputStream(s.getOutputStream());
		} catch (IOException e) {
			System.out.println("Error bei Client " + nr);
			e.printStackTrace();
		}
	}

	/**
	 * The run method is overwritten, due to the fact that AuskunftProtocol extends
	 * Thread In here, the database connection is established and the communication
	 * from the client is analyzed Based on the input from the client, SQL queries
	 * or database updates are executed
	 */
	public void run() {
		try {
			while (true) {
				// only perform if the socket is not closed; the socket should however be closed
				// after every data exchange
				if (!s.isClosed()) {
					toClient.writeObject("Connection established");
					input = fromClient.readLine();
					try {
						// create a database connection
						// Syntax: "jdbc:sqlite:<<database_Name.db>>"
						connection = DriverManager.getConnection("jdbc:sqlite:second.db");
						statement = connection.createStatement();
					} catch (SQLException e) {
						System.err.println(e.getMessage());
					}
					if (input.equalsIgnoreCase("query")) {
						Class.forName("org.sqlite.JDBC");
						basicQuery(); // SQL query for all appointments today
					} else if (input.equalsIgnoreCase("undated")) {
						Class.forName("org.sqlite.JDBC");
						undatedQuery(); // SQL query for all undated appointments
					} else if (input.equalsIgnoreCase("schedule")) {
						scheduleApt(); // SQL update to schedule a certain appointment
					}
					s.close(); // closes the client socket
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method implements the logic to find the next free timeslot if an
	 * unscheduled appointment is supposed to be scheduled Therefore, all active
	 * appointments are analyzed and the "to-be-dated" (tbd)-appointment is shifted
	 * according to the next free slot. In this scenario, weekends are non-working
	 * days. In addition, appointments are only placed between 9:00 am and 4:30 pm
	 * (normal working hours)
	 * 
	 * @param aptList
	 *            - List<Appointment> - should contain all scheduled appointments
	 * @param tbd
	 *            - Appointment - the appointment which should be scheduled
	 * @return - String - "success" if the appointment could be dated; "" if no free
	 *         slot was found
	 */
	private String findDateTime(List<Appointment> aptList, Appointment tbd) {
		try {
			LocalDateTime now, possibleApt;
			Appointment addition, local; // tbd = appointment "to be dated", addition for adding
											// appointments to list, local for iterator
			// now = LocalDateTime.now();
			// LocalDate inTwoWeeks = now.toLocalDate().plusWeeks(2);
			LocalTime startWork = LocalTime.of(9, 0), endWork = LocalTime.of(16, 30);
			Iterator<Appointment> iterator = aptList.iterator();
			if (iterator.hasNext()) {
				while (iterator.hasNext()) {
					local = iterator.next();
					// if the list object's date is before the date tbd, skip until we are at the
					// same date

					// if tbd is before local (case: 2)
					// this means, that no appointment is on this certain day because:
					// case a: n apts have passed (tbd is after them) and the next is after tbd =
					// free date!
					// case b: the only date or all dates are after tbd = free date!
					if (tbd.getDate().isBefore(local.getDate())) {
						return "success";
					}

					// here we need to find a free timeslot on that exact day!!
					else if (local.getDate().equals(tbd.getDate())) {
						// if (local.getDate().getDayOfWeek() == DayOfWeek.SATURDAY
						// || local.getDate().getDayOfWeek() == DayOfWeek.SUNDAY) {
						// // case if local date is saturday or sunday -> apt is invalid!!!!!
						// }
						// tbd start is not allowed to be within another apt (between start and end of
						// another apt)

						// success case?!
						if (tbd.getEnd().plusMinutes(15).isBefore(local.getStart())) {
							// apt is valid!! --> leave it this way!
							// break from loop and return time to app and set it in database as valid date
							System.out.println("Appointment found");
							return "success";
						}

						// change from while to if?! --> check
						// implement equal cases
						if ((tbd.getStart().isAfter(local.getStart()) && tbd.getEnd().isBefore(local.getEnd()))
								|| tbd.getStart().equals(local.getStart()) || tbd.getEnd().equals(local.getEnd())
								|| (tbd.getStart().isBefore(local.getStart())
										&& tbd.getEnd().plusMinutes(15).isAfter(local.getStart()))
								|| (local.getStart().isBefore(tbd.getStart())
										&& local.getEnd().plusMinutes(15).isAfter(local.getStart()))) {
							// reset the start time to the end-time of the previous apt and check again
							tbd.setStart(local.getEnd().plusMinutes(15));

							// if you move into the endWork phase where the employee finishes working, skip
							// to the next day (not SAT/SUN) and reset time to 9am
							if (tbd.getStart().isAfter(endWork)) {
								if (tbd.getDate().getDayOfWeek() == DayOfWeek.FRIDAY) {
									tbd.setDate(tbd.getDate().plusDays(3));
								} else {
									tbd.setDate(tbd.getDate().plusDays(1));
								}
								tbd.setStart(startWork);
							}
						}
					}
				}
			} else {
				// list is empty, create standard apt
				// -------------------------- !!! -----------------------------
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "";
	}

	/**
	 * Method to format Strings, which contain extra ' " ' characters These
	 * characters need to be deleted, otherwise the data cannot be casted into
	 * objects like LocalTime or LocalDate
	 * 
	 * @param str
	 *            - String - the string to be formatted
	 * @return - String - the formatted String
	 */
	private String fomatString(String str) {
		StringBuilder build = new StringBuilder(str);
		if (build.charAt(0) == '\"') {
			build.deleteCharAt(0);
		}
		if (build.charAt(build.length() - 1) == '\"') {
			build.deleteCharAt(build.length() - 1);
		}
		return build.toString();
	}

	/**
	 * The basicQuery() method executes a SQL query for the appointments scheduled
	 * for today and returns those to the client To transport the data to the
	 * client, the query results are transformed into JsonObjects and saved in a
	 * JsonArray. This data can then be serialized and be sent to the client via a
	 * ObjectOutputStream
	 */
	private void basicQuery() {
		try {
			LocalDate today = LocalDate.now();

			// all Appointments from today
			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "JOIN task ON appointment.taskId = task.taskId WHERE date = '" + today.toString()
							+ "' ORDER BY startTime");

			System.out.println(resultSet);
			while (resultSet.next()) {
				value = new JsonObject();
				value.addProperty("firstName", resultSet.getString("firstName"));
				value.addProperty("lastName", resultSet.getString("lastName"));
				value.addProperty("address", resultSet.getString("address"));
				value.addProperty("addition", resultSet.getString("addition"));
				value.addProperty("zip", resultSet.getString("zip"));
				value.addProperty("city", resultSet.getString("city"));
				value.addProperty("counterNr:", resultSet.getString("counterNr"));
				value.addProperty("phone", resultSet.getString("phone"));
				value.addProperty("notes", resultSet.getString("customerNotes"));
				value.addProperty("email", resultSet.getString("email"));
				value.addProperty("mobile", resultSet.getString("mobile"));
				value.addProperty("phoneBusi", resultSet.getString("phoneBusi"));
				value.addProperty("emailBusi", resultSet.getString("emailBusi"));
				value.addProperty("start", resultSet.getString("startTime"));
				value.addProperty("duration", resultSet.getString("taskTime"));
				value.addProperty("id", resultSet.getString("appointmentId"));
				// value.addProperty()
				array.add(value);
				// System.out.println("ResultSet value name: " + resultSet.getString("name"));
			}
			transfer = gson.toJson(array);
			System.out.println(transfer);
			toClient.writeObject(transfer);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * The undatedQuery() method executes a SQL query for the appointments which are
	 * not scheduled yet. The data formatting and transportation to the client is
	 * similar to the basicQuery() method. Read the basicQuery() documentation for
	 * further information
	 */
	private void undatedQuery() {
		try {
			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "JOIN task ON appointment.taskId = task.taskId WHERE status = 0");
			System.out.println(resultSet);
			while (resultSet.next()) {
				value = new JsonObject();
				value.addProperty("firstName", resultSet.getString("firstName"));
				value.addProperty("lastName", resultSet.getString("lastName"));
				value.addProperty("address", resultSet.getString("address"));
				value.addProperty("addition", resultSet.getString("addition"));
				value.addProperty("zip", resultSet.getString("zip"));
				value.addProperty("city", resultSet.getString("city"));
				value.addProperty("counterNr:", resultSet.getString("counterNr"));
				value.addProperty("phone", resultSet.getString("phone"));
				value.addProperty("notes", resultSet.getString("customerNotes"));
				value.addProperty("email", resultSet.getString("email"));
				value.addProperty("mobile", resultSet.getString("mobile"));
				value.addProperty("phoneBusi", resultSet.getString("phoneBusi"));
				value.addProperty("emailBusi", resultSet.getString("emailBusi"));
				value.addProperty("start", resultSet.getString("startTime"));
				value.addProperty("duration", resultSet.getString("taskTime"));
				value.addProperty("id", resultSet.getString("appointmentId"));
				array.add(value);
			}
			transfer = gson.toJson(array);
			System.out.println(transfer);
			toClient.writeObject(transfer);

		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	/**
	 * The scheduleApt() method receives an appointmentId from the client (an
	 * undated appointment) and finds a valid timeslot for the appointment by
	 * calling the findDateTime() method The result of the findDateTime() method is
	 * passed to the client
	 */
	private void scheduleApt() {
		try {
			String appointID = fromClient.readLine();
			//
			// // now as local system time; possibleApt as the possible time for an
			// appointment
			LocalDateTime now, possibleApt;
			Appointment tbd, addition, local; // tbd = appointment "to be dated", addition for adding
			tbd = new Appointment("0", "2018-05-19", "00:00", "00:00", "0", 30, 0);
			// SQL query
			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "JOIN task ON appointment.taskId = task.taskId WHERE appointmentId = '" + appointID
							+ "'");

			while (resultSet.next()) {
				tbd = new Appointment(resultSet.getString("appointmentId"), resultSet.getString("date"),
						resultSet.getString("startTime"), resultSet.getString("endTime"), resultSet.getString("taskId"),
						resultSet.getInt("taskTime"), resultSet.getInt("status"));
			}

			now = LocalDateTime.now();
			LocalDate inTwoWeeks = now.toLocalDate().plusWeeks(2);
			LocalTime startWork = LocalTime.of(9, 0); // , endWork = LocalTime.of(16, 30);

			// tbd = new Appointment("0", "2018-01-01", "09:00", null, null, 30, 0, 0);
			if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SATURDAY)
				inTwoWeeks = inTwoWeeks.plusDays(2);
			if (inTwoWeeks.getDayOfWeek() == DayOfWeek.SUNDAY)
				inTwoWeeks = inTwoWeeks.plusDays(1);
			tbd.setDate(inTwoWeeks);
			tbd.setStart(startWork);

			List<Appointment> aptList = new ArrayList<>(); // store query results

			resultSet = statement.executeQuery(
					"SELECT * FROM ((apartment JOIN CUSTOMER ON apartment.apartmentId = customer.apartmentId) "
							+ "JOIN appointment ON appointment.aptId = apartment.apartmentId)"
							+ "JOIN task ON appointment.taskId = task.taskId WHERE (date >= '" + inTwoWeeks.toString()
							+ "' AND status = 2)");

			while (resultSet.next()) {
				addition = new Appointment(resultSet.getString("appointmentId"), resultSet.getString("date"),
						resultSet.getString("startTime"), resultSet.getString("endTime"), resultSet.getString("taskId"),
						Integer.valueOf(resultSet.getString("taskTime")),
						Integer.valueOf(resultSet.getString("status")));
				aptList.add(addition);
			}
			StringBuilder builder = new StringBuilder(appointID);
			if (builder.charAt(0) == '\"')
				builder.deleteCharAt(0);
			if (builder.charAt(builder.length() - 1) == '\"')
				builder.deleteCharAt(builder.length() - 1);
			appointID = builder.toString();

			String result = findDateTime(aptList, tbd);
			// resultSet = statement.executeQuery("SELECT * FROM appointment WHERE
			// appointmentId = '" + id + "'");
			if (result == "success") {
				// set status to active
				try {
					// statement.executeUpdate("UPDATE Termin SET status = 2 WHERE id =" + id);
					System.out.println("Before Update: " + tbd);
					statement.executeUpdate(
							"UPDATE appointment SET status = 2 WHERE appointmentId = '" + appointID + "'");
					toClient.writeObject("success");
					resultSet = statement
							.executeQuery("SELECT * FROM appointment WHERE appointmentId = '" + appointID + "'");
					System.out.println("Id: " + appointID);
					if (resultSet.next()) {
						System.out.println(resultSet.getString("appointmentId") + "; " + resultSet.getString("status"));
					}
					statement.close();
				} catch (SQLException e) {
					toClient.writeObject("failedSQL");
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				toClient.writeObject("failedApt");
			}
		} catch (IOException e) {

		} catch (SQLException e) {

		}
	}
}
