package ServerTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import com.google.gson.*;

import org.junit.jupiter.api.*;

public class ServerConnectionTest {

	@Test
	public void connectToServer() throws Exception {
		Socket socket = new Socket("localhost", 200);
		ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());
		PrintWriter toServer = new PrintWriter(socket.getOutputStream());
		toServer.println("abf");
		assertEquals((String) fromServer.readObject(), "Connection established");
		socket.close();
	}


}
